require('dotenv').config();

const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');
const db = require('./lib/db');

const DATA_DIR = path.resolve('./data');
const PUBLIC_DIR = path.join(__dirname, '../public');
const INSTALL_LOCK = path.join(DATA_DIR, 'install.lock');

for (const dir of ['backups', 'uploads', 'sessions']) {
  fs.mkdirSync(path.join(DATA_DIR, dir), { recursive: true });
}

function isInstalled() {
  return fs.existsSync(INSTALL_LOCK) || db.userCount() > 0;
}

async function start() {
  await db.init();

  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  const FileStore = require('session-file-store')(session);
  app.use(session({
    store: new FileStore({
      path: path.join(DATA_DIR, 'sessions'),
      ttl: 7 * 24 * 3600,
      retries: 0,
      logFn: function () {}
    }),
    name: 'tmsid',
    secret: process.env.SESSION_SECRET || 'trackmania-web-panel-change-me',
    resave: false,
    saveUninitialized: false,
    rolling: true,
    proxy: true,
    cookie: {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    }
  }));

  app.use('/install', require('./routes/install'));

  app.use((req, res, next) => {
    if (isInstalled()) return next();
    if (req.path.startsWith('/install')) return next();
    return res.redirect('/install');
  });

  app.use('/auth', require('./routes/auth'));
  app.use('/admin', require('./routes/admin'));
  app.use('/api', require('./routes/api'));

  const { requireLogin } = require('./middleware/auth');
  app.get('/me', requireLogin, (req, res) => {
    try {
      const user = db.users.findById(req.session.userId);
      if (!user) return res.status(401).json({ error: 'unauthorized' });
      const allServers = db.servers.findAll();
      const allowed = user.role === 'admin' ? allServers : allServers.filter((s) => db.users.getServers(user.id).includes(s.id));
      res.json({
        user: { id: user.id, username: user.username, role: user.role },
        servers: allowed.map((s) => ({ id: s.id, label: s.label, host: s.host, port: s.port, controllerType: s.controllerType }))
      });
    } catch (err) {
      res.status(500).json({ error: String(err.message || err) });
    }
  });

  app.use(express.static(PUBLIC_DIR));
  app.get('*', function (_req, res) {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
  });

  const PORT = Number(process.env.PORT) || 8088;
  app.listen(PORT, '0.0.0.0', function () {
    console.log(`TRACKMANIA WEB PANEL running on http://0.0.0.0:${PORT}`);
  });
}

start().catch(function (err) {
  console.error(err);
  process.exit(1);
});
