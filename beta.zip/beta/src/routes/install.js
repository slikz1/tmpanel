const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const bcrypt = require('bcryptjs');
const db = require('../lib/db');

const router = express.Router();
const ROOT = path.join(__dirname, '../../');
const DATA_DIR = path.join(ROOT, 'data');
const DEPLOY_DIR = path.join(ROOT, 'deploy');
const ENV_FILE = path.join(ROOT, '.env');
const LOCK_FILE = path.join(DATA_DIR, 'install.lock');

function safeName(input) {
  return String(input || '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'tmserver';
}

function normalizeHost(input) {
  let host = String(input || '').trim().toLowerCase();
  host = host.replace(/^https?:\/\//i, '');
  host = host.replace(/\/.*$/g, '');
  host = host.replace(/:\d+$/g, '');
  return host.trim();
}

function safeHostFileName(input) {
  return normalizeHost(input).replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'panel';
}

function isIpAddress(value) {
  const v = normalizeHost(value);
  if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(v)) return true;
  return /^[a-f0-9:]+$/i.test(v) && v.includes(':');
}

function getSuggestedHost(req) {
  const fwdHost = String(req.headers['x-forwarded-host'] || '').split(',')[0].trim();
  const hostHeader = String(req.headers.host || '').trim();
  const fromHeader = normalizeHost(fwdHost || hostHeader);
  if (fromHeader && fromHeader !== 'localhost' && fromHeader !== '127.0.0.1') return fromHeader;

  const nets = os.networkInterfaces();
  for (const entries of Object.values(nets)) {
    for (const item of entries || []) {
      if (item && item.family === 'IPv4' && !item.internal) return item.address;
    }
  }
  return '127.0.0.1';
}

function resolveInside(base, target) {
  const full = path.resolve(target);
  const baseResolved = path.resolve(base);
  if (!full.startsWith(baseResolved)) throw new Error('Path outside allowed folder');
  return full;
}

function systemChecks() {
  const checks = [];
  checks.push({ label: 'Node.js detected', ok: !!process.version, detail: process.version || 'unknown' });
  checks.push({ label: 'data folder writable', ok: fs.existsSync(DATA_DIR) || (fs.mkdirSync(DATA_DIR, { recursive: true }), true), detail: DATA_DIR });
  for (const dir of ['backups', 'uploads', 'sessions', 'logs']) {
    const full = path.join(DATA_DIR, dir);
    try { fs.mkdirSync(full, { recursive: true }); checks.push({ label: `data/${dir}`, ok: true, detail: full }); }
    catch (e) { checks.push({ label: `data/${dir}`, ok: false, detail: String(e.message || e) }); }
  }
  checks.push({ label: 'Users table OK', ok: db.userCount() >= 0, detail: `users=${db.userCount()}` });
  checks.push({ label: 'Database backend', ok: true, detail: 'This build uses sql.js file storage' });
  return checks;
}

function firstExisting(arr) {
  return arr.find((p) => p && fs.existsSync(p)) || arr[0] || '';
}

function detectPaths(tmRoot, controllerType = 'none') {
  const rawRoot = String(tmRoot || '').trim();
  if (!rawRoot) throw new Error('tmRoot is required');
  const root = path.resolve(rawRoot);
  const lowerType = String(controllerType || 'none').toLowerCase();

  const mapsCandidates = [
    path.join(root, 'GameData', 'Tracks'),
    path.join(root, 'GameData', 'Tracks', 'Challenges'),
    path.join(root, 'UserData', 'Maps'),
    path.join(root, 'Tracks')
  ];
  const matchCandidates = [
    path.join(root, 'GameData', 'Tracks', 'MatchSettings'),
    path.join(root, 'UserData', 'Maps', 'MatchSettings'),
    path.join(root, 'MatchSettings')
  ];
  const dedicatedCandidates = [
    'TrackmaniaServer', 'TrackmaniaServer.exe', 'ManiaPlanetServer', 'ManiaPlanetServer.exe'
  ].map((name) => path.join(root, name));

  const controllerDirs = {
    xaseco: [path.join(root, 'xaseco'), path.join(root, 'XAseco'), path.join(root, 'aseco')],
    pyplanet: [path.join(root, 'pyplanet'), path.join(root, 'PyPlanet')],
    maniacontrol: [path.join(root, 'maniacontrol'), path.join(root, 'ManiaControl')],
    none: []
  };

  const mapsPath = firstExisting(mapsCandidates);
  const matchPath = firstExisting(matchCandidates);
  const dedicatedBinary = firstExisting(dedicatedCandidates);
  const controllerDir = firstExisting(controllerDirs[lowerType] || []);

  const scripts = {
    start: path.join(root, 'start-server.sh'),
    stop: path.join(root, 'stop-server.sh'),
    restart: path.join(root, 'restart-server.sh'),
    status: path.join(root, 'status-server.sh')
  };

  const controllerScripts = lowerType !== 'none' ? {
    start: path.join(controllerDir || root, `start-${lowerType}.sh`),
    stop: path.join(controllerDir || root, `stop-${lowerType}.sh`),
    restart: path.join(controllerDir || root, `restart-${lowerType}.sh`),
    status: path.join(controllerDir || root, `status-${lowerType}.sh`)
  } : {};

  return {
    tmRoot: root,
    filesRoot: root,
    mapsPath,
    matchPath,
    dedicatedBinary,
    controllerDir,
    scripts,
    controllerScripts,
    exists: {
      tmRoot: fs.existsSync(root),
      mapsPath: !!mapsPath && fs.existsSync(mapsPath),
      matchPath: !!matchPath && fs.existsSync(matchPath),
      dedicatedBinary: !!dedicatedBinary && fs.existsSync(dedicatedBinary),
      controllerDir: !!controllerDir && fs.existsSync(controllerDir)
    }
  };
}

function buildServerScripts(opts) {
  const serverDir = path.resolve(opts.serverDir);
  const runUser = String(opts.runUser || 'tm').trim();
  const binaryName = String(opts.binaryName || 'TrackmaniaServer').trim();
  const screenName = safeName(opts.screenName || path.basename(serverDir));
  const dedicatedBinaryPath = String(opts.dedicatedBinaryPath || path.join(serverDir, binaryName)).trim();
  const startArgs = String(opts.startArgs || '/game_settings=MatchSettings/server.xml').trim();

  return {
    'start-server.sh': `#!/usr/bin/env bash\nset -e\ncd "${serverDir}" || exit 1\nif pgrep -af "${binaryName}" >/dev/null; then\n  echo "Server is already running"\n  exit 0\nfi\nsudo -u "${runUser}" screen -dmS "${screenName}" "${dedicatedBinaryPath}" ${startArgs}\n`,
    'stop-server.sh': `#!/usr/bin/env bash\npkill -f "${binaryName}" || true\n`,
    'restart-server.sh': `#!/usr/bin/env bash\nset -e\n"${serverDir}/stop-server.sh"\nsleep 2\n"${serverDir}/start-server.sh"\n`,
    'status-server.sh': `#!/usr/bin/env bash\nif pgrep -af "${binaryName}" >/dev/null; then\n  echo "ONLINE"\n  exit 0\nfi\necho "OFFLINE"\nexit 1\n`
  };
}

function buildControllerScripts(opts) {
  const type = String(opts.controllerType || 'none').trim().toLowerCase();
  const controllerDir = path.resolve(opts.controllerDir || opts.serverDir || '.');
  if (!['xaseco', 'pyplanet', 'maniacontrol'].includes(type)) return null;

  if (type === 'xaseco') {
    return {
      'start-xaseco.sh': `#!/usr/bin/env bash\ncd "${controllerDir}" || exit 1\nscreen -dmS xaseco php aseco.php\n`,
      'stop-xaseco.sh': `#!/usr/bin/env bash\npkill -f aseco.php || true\n`,
      'restart-xaseco.sh': `#!/usr/bin/env bash\n"${controllerDir}/stop-xaseco.sh"\nsleep 2\n"${controllerDir}/start-xaseco.sh"\n`,
      'status-xaseco.sh': `#!/usr/bin/env bash\npgrep -af aseco.php >/dev/null && echo ONLINE || echo OFFLINE\n`
    };
  }
  if (type === 'pyplanet') {
    return {
      'start-pyplanet.sh': `#!/usr/bin/env bash\ncd "${controllerDir}" || exit 1\n./pyplanet.sh start\n`,
      'stop-pyplanet.sh': `#!/usr/bin/env bash\ncd "${controllerDir}" || exit 1\n./pyplanet.sh stop\n`,
      'restart-pyplanet.sh': `#!/usr/bin/env bash\ncd "${controllerDir}" || exit 1\n./pyplanet.sh restart\n`,
      'status-pyplanet.sh': `#!/usr/bin/env bash\npgrep -af pyplanet >/dev/null && echo ONLINE || echo OFFLINE\n`
    };
  }
  return {
    'start-maniacontrol.sh': `#!/usr/bin/env bash\ncd "${controllerDir}" || exit 1\nscreen -dmS maniacontrol php ManiaControl.php\n`,
    'stop-maniacontrol.sh': `#!/usr/bin/env bash\npkill -f ManiaControl.php || true\n`,
    'restart-maniacontrol.sh': `#!/usr/bin/env bash\n"${controllerDir}/stop-maniacontrol.sh"\nsleep 2\n"${controllerDir}/start-maniacontrol.sh"\n`,
    'status-maniacontrol.sh': `#!/usr/bin/env bash\npgrep -af ManiaControl.php >/dev/null && echo ONLINE || echo OFFLINE\n`
  };
}

function buildSystemdService(opts) {
  const serviceName = safeName(opts.serviceName || opts.label || 'tmserver');
  const workingDirectory = path.resolve(opts.workingDirectory || opts.serverDir || '.');
  const user = String(opts.user || 'tm').trim();
  return `[Unit]\nDescription=TrackMania Server - ${opts.label || serviceName}\nAfter=network.target\n\n[Service]\nType=forking\nUser=${user}\nWorkingDirectory=${workingDirectory}\nExecStart=${path.join(workingDirectory, 'start-server.sh')}\nExecStop=${path.join(workingDirectory, 'stop-server.sh')}\nExecReload=${path.join(workingDirectory, 'restart-server.sh')}\nRestart=on-failure\nRestartSec=3\n\n[Install]\nWantedBy=multi-user.target\n`;
}

function buildSudoers(files, linuxUser = 'www-data') {
  return files.map((f) => `${linuxUser} ALL=(ALL) NOPASSWD: ${f}`).join('\n');
}

function ensureDirs() {
  for (const dir of ['backups', 'uploads', 'sessions', 'logs']) {
    fs.mkdirSync(path.join(DATA_DIR, dir), { recursive: true });
  }
  fs.mkdirSync(DEPLOY_DIR, { recursive: true });
}

function buildNginxConfig({ host, port, useLetsEncrypt }) {
  if (!useLetsEncrypt) {
    return `server {\n    listen 80;\n    server_name ${host};\n\n    client_max_body_size 2G;\n\n    location / {\n        proxy_pass http://127.0.0.1:${port};\n        proxy_http_version 1.1;\n        proxy_set_header Host $host;\n        proxy_set_header X-Real-IP $remote_addr;\n        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n        proxy_set_header X-Forwarded-Proto $scheme;\n        proxy_set_header Upgrade $http_upgrade;\n        proxy_set_header Connection "upgrade";\n    }\n}\n`;
  }

  return `server {\n    listen 80;\n    server_name ${host};\n\n    client_max_body_size 2G;\n\n    location /.well-known/acme-challenge/ { root /var/www/certbot; }\n    location / { return 301 https://$host$request_uri; }\n}\n\nserver {\n    listen 443 ssl http2;\n    server_name ${host};\n\n    ssl_certificate /etc/letsencrypt/live/${host}/fullchain.pem;\n    ssl_certificate_key /etc/letsencrypt/live/${host}/privkey.pem;\n\n    client_max_body_size 2G;\n\n    location / {\n        proxy_pass http://127.0.0.1:${port};\n        proxy_http_version 1.1;\n        proxy_set_header Host $host;\n        proxy_set_header X-Real-IP $remote_addr;\n        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n        proxy_set_header X-Forwarded-Proto $scheme;\n        proxy_set_header Upgrade $http_upgrade;\n        proxy_set_header Connection "upgrade";\n    }\n}\n`;
}

function buildCertbotScript(host) {
  return `#!/usr/bin/env bash\nset -e\nsudo mkdir -p /var/www/certbot\nsudo certbot certonly --webroot -w /var/www/certbot -d ${host}\n`;
}

function writeDeployFiles({ host, port, useLetsEncrypt }) {
  if (!host) return { host: '', nginxPath: '', certbotPath: '', useLetsEncrypt: false };
  fs.mkdirSync(DEPLOY_DIR, { recursive: true });
  const fileBase = safeHostFileName(host);
  const nginxPath = path.join(DEPLOY_DIR, `${fileBase}.nginx.conf`);
  fs.writeFileSync(nginxPath, buildNginxConfig({ host, port, useLetsEncrypt }), 'utf8');

  let certbotPath = '';
  if (useLetsEncrypt) {
    certbotPath = path.join(DEPLOY_DIR, `${fileBase}.letsencrypt.sh`);
    fs.writeFileSync(certbotPath, buildCertbotScript(host), 'utf8');
    try { fs.chmodSync(certbotPath, 0o755); } catch {}
  }

  return { host, nginxPath, certbotPath, useLetsEncrypt };
}

router.get('/', (_req, res) => res.sendFile(path.join(ROOT, 'public', 'install.html')));

router.get('/status', (req, res) => {
  const suggestedHost = getSuggestedHost(req);
  const installed = fs.existsSync(LOCK_FILE) || db.userCount() > 0;
  res.json({
    installed,
    checks: systemChecks(),
    appName: process.env.APP_NAME || 'TRACKMANIA WEB PANEL',
    suggestedHost,
    suggestedPanelUrl: `http://${suggestedHost}:${process.env.PORT || 8088}`
  });
});

router.post('/detect', (req, res) => {
  try {
    const tmRoot = String((req.body || {}).tmRoot || '').trim();
    if (!tmRoot) return res.status(400).json({ error: 'tmRoot is required.' });
    const result = detectPaths(tmRoot, (req.body || {}).controllerType || 'none');
    res.json({ ok: true, result });
  } catch (err) {
    res.status(400).json({ error: String(err.message || err) });
  }
});

router.post('/service-preview', (req, res) => {
  try {
    const body = req.body || {};
    const tmRoot = String(body.tmRoot || '').trim();
    if (!tmRoot) return res.status(400).json({ error: 'tmRoot is required.' });
    const service = buildSystemdService({
      label: body.serverLabel || path.basename(tmRoot),
      serviceName: body.serviceName || path.basename(tmRoot),
      workingDirectory: tmRoot,
      serverDir: tmRoot,
      user: body.runUser || 'tm'
    });
    res.json({ ok: true, service });
  } catch (err) {
    res.status(400).json({ error: String(err.message || err) });
  }
});

router.post('/admin-reset', async (req, res) => {
  try {
    if (!(fs.existsSync(LOCK_FILE) || db.userCount() > 0)) {
      return res.status(400).json({ error: 'Panel is not installed yet.' });
    }

    const body = req.body || {};
    const adminUser = String(body.adminUser || '').trim();
    const adminPass = String(body.adminPass || '');
    const adminPass2 = String(body.adminPass2 || '');

    if (!adminUser || !adminPass || !adminPass2) return res.status(400).json({ error: 'Fill all reset fields.' });
    if (adminPass !== adminPass2) return res.status(400).json({ error: 'Passwords do not match.' });
    if (adminPass.length < 8) return res.status(400).json({ error: 'Use at least 8 characters.' });

    const user = db.users.findByUsername(adminUser);
    if (!user) return res.status(404).json({ error: 'Admin user not found.' });
    if (user.role !== 'admin') return res.status(400).json({ error: 'That user is not an admin.' });

    db.users.update(user.id, { password_hash: await bcrypt.hash(adminPass, 12) });
    res.json({ ok: true, message: 'Admin password changed.' });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.post('/setup', async (req, res) => {
  try {
    if (fs.existsSync(LOCK_FILE) || db.userCount() > 0) {
      return res.status(400).json({ error: 'Installer is locked. Delete data/install.lock only if you really want a fresh install.' });
    }

    ensureDirs();
    const body = req.body || {};
    const adminUser = String(body.adminUser || '').trim();
    const adminEmail = String(body.adminEmail || '').trim();
    const adminPass = String(body.adminPass || '');
    const adminPass2 = String(body.adminPass2 || '');
    const serverLabel = String(body.serverLabel || '').trim();
    const serverHost = String(body.serverHost || '127.0.0.1').trim();
    const serverPort = Number(body.serverPort || 5000);
    const rpcUser = String(body.rpcUser || 'SuperAdmin').trim();
    const rpcPass = String(body.rpcPass || '').trim();
    const tmRootRaw = String(body.tmRoot || '').trim();
    if (!adminUser || !adminEmail || !adminPass || !adminPass2) return res.status(400).json({ error: 'Fill all admin fields.' });
    if (adminPass !== adminPass2) return res.status(400).json({ error: 'Admin passwords do not match.' });
    if (adminPass.length < 8) return res.status(400).json({ error: 'Use an admin password with at least 8 characters.' });
    if (!serverLabel || !tmRootRaw) return res.status(400).json({ error: 'Server name and TrackMania root folder are required.' });

    const tmRoot = path.resolve(tmRootRaw);
    const detect = detectPaths(tmRoot, body.controllerType || 'none');
    const filesRoot = path.resolve(String(body.filesRoot || detect.filesRoot || tmRoot).trim());
    const mapsPath = String(body.mapsPath || detect.mapsPath || path.join(tmRoot, 'GameData', 'Tracks')).trim();
    const matchPath = String(body.matchPath || detect.matchPath || path.join(tmRoot, 'GameData', 'Tracks', 'MatchSettings')).trim();
    const controllerType = String(body.controllerType || 'none').trim().toLowerCase();
    const controllerDir = controllerType === 'none' ? '' : path.resolve(String(body.controllerDir || detect.controllerDir || path.join(tmRoot, controllerType)).trim());
    const autoCreate = body.autoCreate !== false;

    fs.mkdirSync(filesRoot, { recursive: true });
    if (controllerDir) fs.mkdirSync(controllerDir, { recursive: true });

    const port = Number(body.port || process.env.PORT || 8088);
    const requestedHost = normalizeHost(body.domain || body.panelHost || body.panelUrl || '') || getSuggestedHost(req);
    const host = normalizeHost(requestedHost);
    const useLetsEncryptRequested = !!body.useLetsEncrypt;
    const useLetsEncrypt = !!host && !isIpAddress(host) && useLetsEncryptRequested;
    const panelProtocol = useLetsEncrypt ? 'https' : 'http';
    const panelUrl = `${panelProtocol}://${host}${(!useLetsEncrypt && port) ? `:${port}` : ''}`;

    let createdFiles = { server: [], controller: [], dataDirs: ['data/backups', 'data/uploads', 'data/sessions', 'data/logs'] };

    if (autoCreate) {
      const serverScripts = buildServerScripts({
        serverDir: filesRoot,
        runUser: body.runUser || 'tm',
        binaryName: body.binaryName || path.basename(detect.dedicatedBinary || 'TrackmaniaServer'),
        dedicatedBinaryPath: detect.dedicatedBinary || path.join(filesRoot, body.binaryName || 'TrackmaniaServer'),
        startArgs: body.startArgs || '/game_settings=MatchSettings/server.xml',
        screenName: body.serviceName || path.basename(filesRoot)
      });
      for (const [filename, content] of Object.entries(serverScripts)) {
        const target = resolveInside(filesRoot, path.join(filesRoot, filename));
        fs.writeFileSync(target, content, 'utf8');
        try { fs.chmodSync(target, 0o755); } catch {}
        createdFiles.server.push(target);
      }

      if (controllerType !== 'none') {
        const controllerScripts = buildControllerScripts({ controllerType, controllerDir, serverDir: filesRoot });
        for (const [filename, content] of Object.entries(controllerScripts || {})) {
          const target = resolveInside(controllerDir, path.join(controllerDir, filename));
          fs.writeFileSync(target, content, 'utf8');
          try { fs.chmodSync(target, 0o755); } catch {}
          createdFiles.controller.push(target);
        }
      }
    }

    const startCmd = String(body.startCmd || `sudo ${path.join(filesRoot, 'start-server.sh')}`).trim();
    const stopCmd = String(body.stopCmd || `sudo ${path.join(filesRoot, 'stop-server.sh')}`).trim();
    const restartCmd = String(body.restartCmd || `sudo ${path.join(filesRoot, 'restart-server.sh')}`).trim();
    const statusCmd = String(body.statusCmd || `sudo ${path.join(filesRoot, 'status-server.sh')}`).trim();

    const controllerStart = controllerType === 'none' ? '' : String(body.controllerStart || `sudo ${path.join(controllerDir, `start-${controllerType}.sh`)}`).trim();
    const controllerStop = controllerType === 'none' ? '' : String(body.controllerStop || `sudo ${path.join(controllerDir, `stop-${controllerType}.sh`)}`).trim();
    const controllerRestart = controllerType === 'none' ? '' : String(body.controllerRestart || `sudo ${path.join(controllerDir, `restart-${controllerType}.sh`)}`).trim();
    const controllerStatus = controllerType === 'none' ? '' : String(body.controllerStatus || `sudo ${path.join(controllerDir, `status-${controllerType}.sh`)}`).trim();

    const sessionSecret = crypto.randomBytes(32).toString('hex');
    const envLines = [
      `PORT=${port}`,
      `DATABASE_URL=file:./data/tm_panel.db`,
      `SESSION_SECRET=${sessionSecret}`,
      `APP_NAME=TRACKMANIA WEB PANEL`,
      `APP_URL=${panelUrl}`,
      `UPLOAD_DIR=./data/uploads`,
      `BACKUP_DIR=./data/backups`,
      `SESSION_DIR=./data/sessions`,
      `LOG_DIR=./data/logs`
    ];
    fs.writeFileSync(ENV_FILE, envLines.join('\n') + '\n', 'utf8');

    const deployInfo = writeDeployFiles({ host, port, useLetsEncrypt });

    const adminId = db.users.create(adminUser, await bcrypt.hash(adminPass, 12), 'admin');
    const serverId = db.servers.create({
      label: serverLabel,
      game: 'TrackMania',
      host: serverHost,
      port: serverPort,
      rpcUser,
      rpcPass,
      mapsPath,
      matchPath,
      filesRoot,
      dedicatedCmds: { start: startCmd, stop: stopCmd, restart: restartCmd, status: statusCmd },
      pyplanetCmds: {},
      controllerType,
      controllerCmds: controllerType === 'none' ? {} : { start: controllerStart, stop: controllerStop, restart: controllerRestart, status: controllerStatus },
      backupConfig: {},
      controllerEnabled: controllerType !== 'none',
      nodeId: null
    });
    db.users.setServers(adminId, [serverId]);

    const lock = {
      installedAt: new Date().toISOString(),
      appName: 'TRACKMANIA WEB PANEL',
      adminUser,
      adminEmail,
      firstServer: serverLabel,
      controllerType,
      filesRoot,
      panelUrl,
      host,
      useLetsEncrypt,
      note: 'installer with host normalization and admin reset'
    };
    fs.writeFileSync(LOCK_FILE, JSON.stringify(lock, null, 2), 'utf8');

    const sudoers = buildSudoers(createdFiles.server.concat(createdFiles.controller));
    res.json({
      ok: true,
      next: '/',
      createdFiles,
      sudoers,
      deployInfo,
      panelUrl,
      warning: useLetsEncryptRequested && !useLetsEncrypt && isIpAddress(host) ? 'Lets Encrypt was skipped because an IP address was used. Use a real domain for SSL.' : ''
    });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

module.exports = router;
