// src/routes/api.js
const express = require('express');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const db = require('../lib/db');
const { withClient } = require('../lib/gbx');
const { requireLogin, requireAdmin } = require('../middleware/auth');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
let S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, ListObjectsV2Command, HeadObjectCommand;
try {
  ({ S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, ListObjectsV2Command, HeadObjectCommand } = require('@aws-sdk/client-s3'));
} catch (e) {
  console.warn('S3 SDK not installed - S3 backup features disabled');
}

const router = express.Router();
let mysql = null;
try { mysql = require('mysql2/promise'); } catch (e) {}

// Public news for login and dashboard
router.get('/news', (_req, res) => {
  try { res.json(db.news.findAll()); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

// ── /api/tm  — raw GBX test/debug endpoint (no sid needed) ──────
router.post('/tm', async (req, res) => {
  const { action, host, port, password, user: rpcUser = 'SuperAdmin' } = req.body || {};
  const { withClient } = require('../lib/gbx');

  try {
    if (action === 'debug' || action === 'ping' || action === 'test') {
      // Test connection and return server info
      const result = await withClient(host, parseInt(port), rpcUser, password, async c => {
        const [name, version, status, players] = await Promise.all([
          c.call('GetServerName'),
          c.call('GetVersion'),
          c.call('GetStatus'),
          c.call('GetPlayerList', 100, 0),
        ]).catch(async () => {
          // Fallback: just get version
          const v = await c.call('GetVersion');
          return [null, v, null, []];
        });
        return { ok: true, name, version, status, playerCount: (players||[]).length };
      });
      return res.json(result);
    }

    if (action === 'call') {
      // Raw GBX call: { action:'call', method:'GetServerName', args:[] }
      const { method, args = [] } = req.body;
      if (!method) return res.status(400).json({ error: 'method required' });
      const result = await withClient(host, parseInt(port), rpcUser, password, c => c.call(method, ...args));
      return res.json({ ok: true, result });
    }

    return res.status(400).json({ error: `Unknown action "${action}". Use: debug, ping, call` });
  } catch (err) {
    return res.status(200).json({ ok: false, error: err.message });
  }
});

router.use(requireLogin);

router.use((req, res, next) => {
  const blocked = ['/news', '/support', '/faq'];
  if (blocked.some((prefix) => req.path === prefix || req.path.startsWith(prefix + '/')) || req.path.includes('/leaderboard/')) {
    return res.status(404).json({ error: 'removed' });
  }
  next();
});


router.post('/news', requireAdmin, (req, res) => {
  try {
    const d = req.body || {};
    const type = ['info','update','alert'].includes(String(d.type || '').trim()) ? String(d.type).trim() : 'info';
    const message = String(d.message || '').trim();
    if (!message) return res.status(400).json({ error: 'message required' });
    const id = db.news.upsert({ id: d.id ? Number(d.id) : null, type, date: String(d.date || '').trim(), message });
    res.json({ ok: true, id });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/news/:id', requireAdmin, (req, res) => {
  try { db.news.delete(Number(req.params.id)); res.json({ ok: true }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});


const BACKUP_DIR = path.resolve(process.env.BACKUP_DIR || './data/backups');
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './data/uploads');
const DATA_DIR = path.resolve('./data');

// ── helpers ──────────────────────────────────────────────────────
function mergeCmdObjects(base, override) {
  return Object.assign({}, base || {}, override || {});
}

function getServerForUser(req, sid) {
  const s = db.servers.findById(Number(sid));
  if (!s) throw Object.assign(new Error('Server not found'), { status: 404 });
  if (req.session.role !== 'admin') {
    const allowed = db.users.getServers(req.session.userId);
    if (!allowed.includes(s.id)) throw Object.assign(new Error('Forbidden'), { status: 403 });
  }
  if (s.nodeId) {
    const node = db.nodeProfiles.findById(Number(s.nodeId));
    if (node) {
      return Object.assign({}, s, {
        host: s.host || node.rpcHost || node.sshHost || '',
        mapsPath: s.mapsPath || node.mapsPath || '',
        matchPath: s.matchPath || node.matchPath || '',
        filesRoot: s.filesRoot || node.filesRoot || node.tmRoot || '',
        dedicatedCmds: mergeCmdObjects(node.dedicatedCmds, s.dedicatedCmds),
        controllerType: s.controllerType || node.controllerType || 'xaseco',
        controllerCmds: mergeCmdObjects(node.controllerCmds, s.controllerCmds),
        _node: node
      });
    }
  }
  return s;
}

function runCmd(cmd, timeout = 35000, env = null) {
  return new Promise(resolve => {
    const execEnv = env ? Object.assign({}, process.env, env) : process.env;
    exec(cmd, { timeout, shell: '/bin/bash', env: execEnv }, (err, stdout, stderr) => {
      resolve((stdout || '') + (stderr || '') || (err?.message || ''));
    });
  });
}

function safePath(base, rel) {
  base = path.resolve(base);
  rel = (rel || '').replace(/\\/g, '/').replace(/^\/+/, '');
  const full = path.resolve(base, rel);
  if (!full.startsWith(base)) throw new Error('invalid path');
  return full;
}

function fsBase(server, root) {
  if (root === 'maps') return server.mapsPath || '/';
  if (root === 'match') return server.matchPath || server.mapsPath || '/';
  if (root === 'server') return server.filesRoot || server.mapsPath || '/';
  throw new Error('invalid root');
}

function inferTmRoot(server) {
  const roots = [server.filesRoot, server.matchPath && path.dirname(path.dirname(server.matchPath)), server.mapsPath && path.dirname(path.dirname(server.mapsPath))].filter(Boolean);
  return roots[0] || server.filesRoot || '/';
}

function listFoldersRecursive(base, rel = '', out = []) {
  const dir = safePath(base, rel);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return out;
  out.push(rel.replace(/\\/g, '/'));
  for (const name of fs.readdirSync(dir)) {
    const subRel = rel ? path.posix.join(rel.replace(/\\/g, '/'), name) : name;
    const full = safePath(base, subRel);
    try { if (fs.statSync(full).isDirectory()) listFoldersRecursive(base, subRel, out); } catch {}
  }
  return out;
}

function listMapsRecursive(base, rel = '', recursive = false, out = []) {
  const dir = safePath(base, rel);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return out;
  for (const name of fs.readdirSync(dir)) {
    const subRel = rel ? path.posix.join(rel.replace(/\\/g, '/'), name) : name;
    const full = safePath(base, subRel);
    let st = null; try { st = fs.statSync(full); } catch {}
    if (!st) continue;
    if (st.isDirectory()) { if (recursive) listMapsRecursive(base, subRel, true, out); continue; }
    if (/\.challenge\.gbx$/i.test(name)) out.push(subRel.replace(/\//g, '\\'));
  }
  return out.sort((a,b)=>a.localeCompare(b));
}

function listFilesRecursive(base, rel = '', recursive = false, rx = /.*/, out = []) {
  const dir = safePath(base, rel);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return out;
  for (const name of fs.readdirSync(dir)) {
    const subRel = rel ? path.posix.join(rel.replace(/\\/g, '/'), name) : name;
    const full = safePath(base, subRel);
    let st = null; try { st = fs.statSync(full); } catch {}
    if (!st) continue;
    if (st.isDirectory()) { if (recursive) listFilesRecursive(base, subRel, true, rx, out); continue; }
    if (rx.test(name)) out.push(subRel.replace(/\\/g, '/'));
  }
  return out.sort((a,b)=>a.localeCompare(b));
}

function matchSettingStartupName(input) {
  const v = String(input || '').replace(/\\/g, '/');
  const idx = v.toLowerCase().indexOf('matchsettings/');
  return idx >= 0 ? v.slice(idx + 'matchsettings/'.length) : path.posix.basename(v);
}

function patchStartupCommand(cmd, filename) {
  if (!cmd) return cmd;
  const target = 'MatchSettings/' + matchSettingStartupName(filename);
  if (/\/game_settings=\S+/i.test(cmd)) return cmd.replace(/\/game_settings=\S+/i, '/game_settings=' + target);
  if (/TrackmaniaServer/.test(cmd)) return cmd + ' /game_settings=' + target;
  return cmd;
}

function patchStartupScriptContent(content, filename) {
  const target = 'MatchSettings/' + matchSettingStartupName(filename);
  if (/\/game_settings="[^"]+"/i.test(content)) return content.replace(/\/game_settings="[^"]+"/i, '/game_settings="' + target + '"');
  if (/\/game_settings=\S+/i.test(content)) return content.replace(/\/game_settings=\S+/i, '/game_settings=' + target);
  return content.replace(/(TrackmaniaServer[^\n]*)/, '$1 /game_settings=' + target);
}

function parseMatchSettingsXml(content) {
  const get = (tag) => {
    const rx = new RegExp('<' + tag + '>[\\s\\S]*?<\/' + tag + '>', 'i');
    const m = content.match(rx);
    if (!m) return '';
    return m[0].replace(new RegExp('^<' + tag + '>|<\/' + tag + '>$', 'gi'), '').trim();
  };
  const maps = [...content.matchAll(/<challenge>[\s\S]*?<file>\s*([\s\S]*?)\s*<\/file>[\s\S]*?<\/challenge>/gi)].map(m => m[1].trim());
  const out = {
    mode: Number(get('game_mode') || 1),
    startindex: Number(get('startindex') || 0),
    chat_time: Number(get('chat_time') || 0),
    finishtimeout: Number(get('finishtimeout') || 0),
    allwarmupduration: Number(get('allwarmupduration') || 0),
    disablerespawn: Number(get('disablerespawn') || 0),
    forceshowallopponents: Number(get('forceshowallopponents') || 0),
    rounds_pointslimit: Number(get('rounds_pointslimit') || 0),
    rounds_usenewrules: Number(get('rounds_usenewrules') || 0),
    team_pointslimit: Number(get('team_pointslimit') || 0),
    team_maxpoints: Number(get('team_maxpoints') || 0),
    timeattack_limit: Number(get('timeattack_limit') || 0),
    timeattack_synchstartperiod: Number(get('timeattack_synchstartperiod') || 0),
    laps_nblaps: Number(get('laps_nblaps') || 0),
    cup_pointslimit: Number(get('cup_pointslimit') || 0),
    cup_nbwinners: Number(get('cup_nbwinners') || 0),
    warmup: Number(get('warmup') || 0),
    random_map_order: Number(get('random_map_order') || 0),
    maps,
  };
  return out;
}

function newestFile(files) {
  const existing = files.filter(f => { try { return fs.statSync(f).isFile(); } catch { return false; } });
  if (!existing.length) return null;
  return existing.sort((a, b) => fs.statSync(b).mtime - fs.statSync(a).mtime)[0];
}

function resolveLogPath(server, value) {
  if (!value) return null;
  value = String(value).trim();

  // 1) Glob pattern
  if (/[*?[]/.test(value)) {
    const dir = path.dirname(value);
    const base = path.basename(value);
    const rx = new RegExp('^' + base.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$', 'i');
    try {
      const matches = fs.readdirSync(dir).filter(f => rx.test(f)).map(f => path.join(dir, f));
      return newestFile(matches);
    } catch { return null; }
  }

  // 2) Direct path exists
  if (fs.existsSync(value)) {
    if (fs.statSync(value).isDirectory()) {
      try { return newestFile(fs.readdirSync(value).map(f => path.join(value, f))); } catch { return null; }
    }
    return value;
  }

  // 3) Exact file not found → search same directory
  const dir = path.dirname(value);
  if (fs.existsSync(dir)) {
    try {
      const allLogs = fs.readdirSync(dir).filter(f => /\.(txt|log)$/i.test(f)).map(f => path.join(dir, f));
      // Prefer files matching same prefix (first 4 chars)
      const prefix = path.basename(value).replace(/\.[^.]+$/, '').slice(0, 4).toLowerCase();
      const preferred = prefix ? allLogs.filter(f => path.basename(f).toLowerCase().startsWith(prefix)) : [];
      const pick = newestFile(preferred.length ? preferred : allLogs);
      if (pick) return pick;
    } catch {}
  }

  // 4) Fallback: filesRoot subdirs and mapsPath parent
  const roots = [
    server && server.filesRoot,
    server && server.mapsPath && path.dirname(path.dirname(server.mapsPath)),
  ].filter(Boolean);
  for (const root of roots) {
    for (const sub of ['Logs', 'logs', 'Log', 'log']) {
      const logsDir = path.join(root, sub);
      if (fs.existsSync(logsDir)) {
        try {
          const pick = newestFile(fs.readdirSync(logsDir).filter(f => /\.(txt|log)$/i.test(f)).map(f => path.join(logsDir, f)));
          if (pick) return pick;
        } catch {}
      }
    }
  }
  return null;
}


function bdir(sid) {
  const d = path.join(BACKUP_DIR, String(sid));
  fs.mkdirSync(d, { recursive: true });
  return d;
}


function backupCfg(server) {
  const cfg = (server && server.backupConfig && typeof server.backupConfig === 'object') ? server.backupConfig : {};
  const lb = (cfg.leaderboardDb && typeof cfg.leaderboardDb === 'object') ? cfg.leaderboardDb : {};
  return {
    mode: cfg.mode || 'local',
    includeDb: cfg.includeDb !== false,
    dbType: cfg.dbType || 'sqlite',
    sqlitePath: cfg.sqlitePath || '',
    s3Enabled: !!cfg.s3Enabled,
    s3Endpoint: cfg.s3Endpoint || '',
    s3Bucket: cfg.s3Bucket || '',
    s3Region: cfg.s3Region || 'us-east-1',
    s3AccessKey: cfg.s3AccessKey || '',
    s3SecretKey: cfg.s3SecretKey || '',
    s3Prefix: cfg.s3Prefix || '',
    s3ForcePathStyle: cfg.s3ForcePathStyle !== false,
    retentionLocal: Math.min(7, Math.max(1, Number(cfg.retentionLocal || 5))),
    retentionS3: Math.min(7, Math.max(1, Number(cfg.retentionS3 || 7))),
    includeXaseco: cfg.includeXaseco !== false,
    dbAlwaysDump: cfg.dbAlwaysDump !== false,
    dbHost: cfg.dbHost || cfg.mysqlHost || lb.host || '127.0.0.1',
    dbPort: Number(cfg.dbPort || cfg.mysqlPort || lb.port || 3306),
    dbName: cfg.dbName || cfg.mysqlDb || lb.database || '',
    dbUser: cfg.dbUser || cfg.mysqlUser || lb.user || '',
    dbPass: cfg.dbPass || cfg.mysqlPass || lb.password || '',
    schedule: cfg.schedule || { type: 'manual', time: '03:00', weekday: 1 }
  };
}


function backupKey(server, name) {
  const cfg = backupCfg(server);
  const prefix = String(cfg.s3Prefix || '').replace(/^\/+|\/+$/g, '');
  const parts = [];
  if (prefix) parts.push(prefix);
  parts.push(String(server.id));
  parts.push(name);
  return parts.join('/');
}

function s3EnabledFor(server) {
  const cfg = backupCfg(server);
  return !!(
    S3Client &&
    cfg &&
    cfg.s3Enabled === true &&
    cfg.s3Endpoint &&
    cfg.s3Bucket &&
    cfg.s3Region &&
    cfg.s3AccessKey &&
    cfg.s3SecretKey
  );
}

function s3ClientFor(server) {
  const cfg = backupCfg(server);
  if (!s3EnabledFor(server)) throw new Error('S3 is not configured');
  return new S3Client({
    region: cfg.s3Region || 'us-east-1',
    endpoint: cfg.s3Endpoint,
    forcePathStyle: cfg.s3ForcePathStyle !== false,
    credentials: { accessKeyId: cfg.s3AccessKey, secretAccessKey: cfg.s3SecretKey }
  });
}


function guessControllerRoots(server) {
  const hits = new Set();
  const cc = server && server.controllerCmds && typeof server.controllerCmds === 'object' ? server.controllerCmds : {};
  const candidates = [cc.start, cc.stop, cc.restart, cc.status, cc.logfile, cc.log, server.filesRoot].filter(Boolean);
  for (const raw of candidates) {
    const m = String(raw).match(/\/home\/[^\s'"`]+\/xaseco(?:\/[^\s'"`]*)?/i);
    if (m && fs.existsSync(m[0])) {
      let p = m[0];
      try {
        const st = fs.statSync(p);
        if (st.isFile()) p = path.dirname(p);
      } catch {}
      hits.add(p);
    }
  }
  return Array.from(hits);
}

function guessBackupRoots(server) {
  const cfg = backupCfg(server);
  const roots = [server.filesRoot, server.mapsPath, server.matchPath];
  if (cfg.includeXaseco) roots.push(...guessControllerRoots(server));
  return roots.filter(Boolean).filter((v, i, a) => a.indexOf(v) === i && fs.existsSync(v));
}

function nextSchedulePreview(schedule) {
  const s = schedule || { type: 'manual', time: '03:00' };
  if (!s.type || s.type === 'manual') return null;
  const now = new Date();
  const hhmm = String(s.time || '03:00').split(':');
  const h = Number(hhmm[0] || 3), m = Number(hhmm[1] || 0);
  const next = new Date(now);
  next.setSeconds(0, 0);
  next.setHours(h, m, 0, 0);
  if (s.type === 'daily') {
    if (next <= now) next.setDate(next.getDate() + 1);
    return next.toISOString();
  }
  if (s.type === 'weekly') {
    const target = Number(s.weekday || 1); // Monday
    let delta = (target - (now.getDay() || 7));
    if (delta < 0 || (delta === 0 && next <= now)) delta += 7;
    next.setDate(now.getDate() + delta);
    return next.toISOString();
  }
  if (s.type === 'monthly') {
    const day = Math.max(1, Math.min(28, Number(s.day || 1)));
    next.setDate(day);
    if (next <= now) next.setMonth(next.getMonth() + 1);
    return next.toISOString();
  }
  return null;
}

async function uploadBackupToS3(server, fullPath, name) {
  const cfg = backupCfg(server);
  const client = s3ClientFor(server);
  await client.send(new PutObjectCommand({
    Bucket: cfg.s3Bucket,
    Key: backupKey(server, name),
    Body: fs.createReadStream(fullPath),
    ContentType: 'application/gzip'
  }));
}

async function listS3Backups(server) {
  if (!s3EnabledFor(server)) return [];
  const cfg = backupCfg(server);
  const client = s3ClientFor(server);
  const Prefix = backupKey(server, '').replace(/\/$/, '') + '/';
  const out = await client.send(new ListObjectsV2Command({ Bucket: cfg.s3Bucket, Prefix }));
  return (out.Contents || []).filter(x => x.Key && x.Key.endsWith('.tar.gz')).map(x => ({
    id: 's3:' + path.basename(x.Key),
    source: 's3',
    name: path.basename(x.Key),
    size: Number(x.Size || 0),
    created_at: x.LastModified ? new Date(x.LastModified).toISOString() : null,
    key: x.Key,
    download_url: `/api/${server.id}/backups/download/s3/${encodeURIComponent(path.basename(x.Key))}`
  }));
}

async function deleteS3Backup(server, name) {
  const cfg = backupCfg(server);
  const client = s3ClientFor(server);
  await client.send(new DeleteObjectCommand({ Bucket: cfg.s3Bucket, Key: backupKey(server, name) }));
}

async function streamS3Backup(server, name, res) {
  const cfg = backupCfg(server);
  const client = s3ClientFor(server);
  const out = await client.send(new GetObjectCommand({ Bucket: cfg.s3Bucket, Key: backupKey(server, name) }));
  res.setHeader('Content-Type', 'application/gzip');
  res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
  out.Body.pipe(res);
}

async function downloadS3BackupToLocal(server, name) {
  const tmp = path.join(bdir(server.id), `.__tmp_restore_${Date.now()}_${name}`);
  const cfg = backupCfg(server);
  const client = s3ClientFor(server);
  const out = await client.send(new GetObjectCommand({ Bucket: cfg.s3Bucket, Key: backupKey(server, name) }));
  await new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(tmp);
    out.Body.pipe(ws);
    out.Body.on('error', reject);
    ws.on('finish', resolve);
    ws.on('error', reject);
  });
  return tmp;
}

async function applyRetention(server) {
  const cfg = backupCfg(server);
  const localFiles = fs.readdirSync(bdir(server.id)).filter(f => f.endsWith('.tar.gz')).sort().reverse();
  if (cfg.retentionLocal > 0 && localFiles.length > cfg.retentionLocal) {
    for (const name of localFiles.slice(cfg.retentionLocal)) {
      try { fs.unlinkSync(path.join(bdir(server.id), name)); } catch {}
    }
  }
  if (cfg.retentionS3 > 0 && s3EnabledFor(server)) {
    const s3Items = await listS3Backups(server);
    if (s3Items.length > cfg.retentionS3) {
      for (const item of s3Items.sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).slice(cfg.retentionS3)) {
        try { await deleteS3Backup(server, item.name); } catch {}
      }
    }
  }
}


async function makeMysqlDump(cfg, outFile) {
  if (!cfg.dbName || !cfg.dbUser) {
    throw new Error('DB name and DB user are required for MySQL backups');
  }

  const env = Object.assign({}, process.env, {
    MYSQL_PWD: String(cfg.dbPass || '')
  });

  const host = shellEscape(cfg.dbHost || '127.0.0.1');
  const port = shellEscape(String(cfg.dbPort || 3306));
  const user = shellEscape(cfg.dbUser);
  const db = shellEscape(cfg.dbName);
  const out = shellEscape(outFile);

  const cmd = `bash -o pipefail -lc "mysqldump -h ${host} -P ${port} -u ${user} --databases ${db} --single-transaction --quick --routines --events --triggers | gzip -c > ${out}"`;
  const output = await runCmd(cmd, 120000, env);

  if (!fs.existsSync(outFile)) {
    throw new Error('MySQL dump file was not created' + (output ? ': ' + output.trim() : ''));
  }

  const st = fs.statSync(outFile);
  if (!st.size || st.size < 40) {
    try { fs.unlinkSync(outFile); } catch {}
    throw new Error('MySQL dump file is empty' + (output ? ': ' + output.trim() : ''));
  }

  const verify = await runCmd(`bash -lc "gunzip -c ${out} | head -n 5"`, 20000, env);
  if (!/MySQL dump|MariaDB dump|CREATE DATABASE|USE `|CREATE TABLE/i.test(String(verify || ''))) {
    try { fs.unlinkSync(outFile); } catch {}
    throw new Error('MySQL dump verification failed' + (verify ? ': ' + String(verify).trim() : ''));
  }
}


async function makeBackup(server) {
  const cfg = backupCfg(server);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const name = `${stamp}.tar.gz`;
  const full = path.join(bdir(server.id), name);
  const stage = path.join(bdir(server.id), `.__stage_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`);
  fs.mkdirSync(stage, { recursive: true });

  const roots = guessBackupRoots(server);
  for (const root of roots) {
    const base = path.basename(root.replace(/\/$/, '')) || 'root';
    await runCmd(`mkdir -p ${JSON.stringify(path.join(stage, 'files', base))} && cp -a ${JSON.stringify(root + '/.')} ${JSON.stringify(path.join(stage, 'files', base))} 2>/dev/null || true`, 120000);
  }

  if (cfg.includeDb) {
    fs.mkdirSync(path.join(stage, 'db'), { recursive: true });
    const latestDir = path.join(bdir(server.id), 'latest-db');
    fs.mkdirSync(latestDir, { recursive: true });
    if (cfg.dbType === 'sqlite' && cfg.sqlitePath && fs.existsSync(cfg.sqlitePath)) {
      const base = path.basename(cfg.sqlitePath);
      fs.copyFileSync(cfg.sqlitePath, path.join(stage, 'db', base));
      if (cfg.dbAlwaysDump) fs.copyFileSync(cfg.sqlitePath, path.join(latestDir, base));
    } else if (cfg.dbType === 'mysql') {
      const dumpName = (cfg.dbName || 'database') + '.sql.gz';
      const stageDump = path.join(stage, 'db', dumpName);
      await makeMysqlDump(cfg, stageDump);
      if (cfg.dbAlwaysDump) {
        const latestDump = path.join(latestDir, dumpName);
        try { fs.copyFileSync(stageDump, latestDump); } catch {}
      }
    }
  }

  await runCmd(`tar czf ${JSON.stringify(full)} -C ${JSON.stringify(stage)} .`, 120000);
  await runCmd(`rm -rf ${JSON.stringify(stage)}`);

  if (cfg.mode === 's3' || cfg.mode === 'both') {
    if (!s3EnabledFor(server)) throw new Error('Backup mode requires S3 but S3 is not configured');
    await uploadBackupToS3(server, full, name);
    if (cfg.mode === 's3') {
      try { fs.unlinkSync(full); } catch {}
    }
  }

  await applyRetention(server);
  return { ok: true, id: name, local: fs.existsSync(full), s3: s3EnabledFor(server) && (cfg.mode === 's3' || cfg.mode === 'both') };
}

async function restoreBackup(server, name, source) {
  const cfg = backupCfg(server);
  let archivePath = null;
  let cleanup = false;
  if (source === 's3') {
    archivePath = await downloadS3BackupToLocal(server, name);
    cleanup = true;
  } else {
    archivePath = path.resolve(path.join(bdir(server.id), name));
    if (!archivePath.startsWith(path.resolve(bdir(server.id))) || !fs.existsSync(archivePath)) throw new Error('not found');
  }

  const stage = path.join(bdir(server.id), `.__restore_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`);
  fs.mkdirSync(stage, { recursive: true });
  await runCmd(`tar xzf ${JSON.stringify(archivePath)} -C ${JSON.stringify(stage)}`, 120000);

  const filesDir = path.join(stage, 'files');
  if (fs.existsSync(filesDir)) {
    for (const root of guessBackupRoots(server)) {
      const base = path.basename(root.replace(/\/$/, '')) || 'root';
      const src = path.join(filesDir, base);
      if (fs.existsSync(src)) {
        fs.mkdirSync(root, { recursive: true });
        await runCmd(`cp -a ${JSON.stringify(src + '/.')} ${JSON.stringify(root)} 2>/dev/null || true`, 120000);
      }
    }
  }

  if (cfg.includeDb && cfg.dbType === 'sqlite' && cfg.sqlitePath) {
    const dbDir = path.join(stage, 'db');
    if (fs.existsSync(dbDir)) {
      const files = fs.readdirSync(dbDir);
      if (files.length) {
        fs.mkdirSync(path.dirname(cfg.sqlitePath), { recursive: true });
        fs.copyFileSync(path.join(dbDir, files[0]), cfg.sqlitePath);
      }
    }
  }

  await runCmd(`rm -rf ${JSON.stringify(stage)}`);
  if (cleanup) { try { fs.unlinkSync(archivePath); } catch {} }
  return { ok: true };
}


// Detect if server is TMNF (uses Challenge* methods) or TM2/MP (uses Map* methods)
const TMNF_METHODS = {
  GetMapList:           'GetChallengeList',
  GetCurrentMapInfo:    'GetCurrentChallengeInfo',
  GetMapInfo:           'GetChallengeInfo',
  ChooseNextMap:        'ChooseNextChallenge',
  RemoveMap:            'RemoveChallenge',
  NextMap:              'NextChallenge',
};

async function callCompat(c, method, ...args) {
  // Try modern method first, fall back to TMNF legacy name on any error
  try {
    return await c.call(method, ...args);
  } catch(e) {
    const fallback = TMNF_METHODS[method];
    if (fallback) {
      try { return await c.call(fallback, ...args); } catch(e2) { throw e2; }
    }
    throw e;
  }
}

// Normalize map object - TMNF returns Challenge structs with same fields
function normalizeMap(m) {
  if (!m) return m;
  // TMNF ChallengeInfo uses same field names (Name, UId, Author, FileName, Environnement)
  // so no remapping needed - just ensure consistency
  return {
    Name: m.Name || m.name || '',
    UId: m.UId || m.Uid || m.uid || '',
    FileName: m.FileName || m.filename || '',
    Author: m.Author || m.author || '',
    AuthorLogin: m.AuthorLogin || m.Author || '',
    Environnement: m.Environnement || m.Environment || m.environnement || '',
  };
}

// ── Status ───────────────────────────────────────────────────────
router.get('/:sid/status', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    try {
      const result = await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
        // Call each individually so one failure doesn't kill everything
        const safe = async (fn) => { try { return await fn(); } catch { return null; } };

        const [name, status, players, map] = await Promise.all([
          safe(() => c.call('GetServerName')),
          safe(() => c.call('GetStatus')),
          safe(() => c.call('GetPlayerList', 400, 0)),
          safe(() => callCompat(c, 'GetCurrentMapInfo')),
        ]);

        // GetVersion to detect game type
        const version = await safe(() => c.call('GetVersion'));
        const gameVer = version ? (version.Name || version.name || '') : '';

        const mapObj = normalizeMap(map);
        return {
          ok: true,
          name: (typeof name === 'string' ? name : (name && name.Value ? name.Value : String(name||''))),
          status: status,
          nbplayers: Array.isArray(players) ? players.length : 0,
          current: mapObj ? mapObj.Name : 'n/a',
          env: mapObj ? mapObj.Environnement : '',
          game: gameVer,
        };
      });
      res.json(result);
    } catch(e) {
      // Log actual error for debugging
      const errMsg = e.message || 'offline';
      console.error('[status] '+s.label+' error:', errMsg);
      res.json({ ok: false, error: errMsg });
    }
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Players ──────────────────────────────────────────────────────
router.get('/:sid/players', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const q = (req.query.q||'').toLowerCase();
    try {
      const players = await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
        // Get basic list first
        const list = await c.call('GetPlayerList', 500, 0);
        // Enrich with detailed info in parallel (TMNF has lots more)
        const detailed = await Promise.all(list.map(async p => {
          try {
            const d = await c.call('GetDetailedPlayerInfo', p.Login);
            // LadderStats contains PlayerRankings array
            const lr = d.LadderStats && d.LadderStats.PlayerRankings && d.LadderStats.PlayerRankings[0];
            return {
              ...p,
              IPAddress:    d.IPAddress    || '',
              Language:     d.Language     || '',
              Path:         d.Path         || '',       // "World|Europe|Switzerland|Zurich"
              LadderScore:  lr ? (lr.Score || p.LadderScore || 0) : (p.LadderScore||0),
              LadderRank:   lr ? (lr.Ranking || 0) : 0,
              // TMNF match stats
              Wins:         d.Wins         || 0,
              Draws:        d.NbrOfDraws   || d.Draws || 0,
              Losses:       d.NbrOfLosses  || d.Losses || 0,
              Shots:        d.NbrOfShots   || 0,
              LastGame:     d.LastGameScore || 0,
              IsSpectator:  p.SpectatorStatus > 0,
              // Avatar skin
              Avatar:       d.Avatar       || '',
            };
          } catch {
            return { ...p, IsSpectator: (p.SpectatorStatus||0) > 0 };
          }
        }));
        return detailed;
      });
      const filtered = q ? players.filter(p => (p.Login||'').toLowerCase().includes(q)||(p.NickName||'').toLowerCase().includes(q)) : players;
      res.json(filtered);
    } catch { res.json([]); }
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/players/action', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { login, action } = req.body;
    if (!login) return res.status(400).json({ error: 'login required' });
    await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      const map = { kick:'Kick', ban:'Ban', unban:'UnBan', black:'BlackList', unblack:'UnBlackList' };
      if (action === 'kick') await c.call('Kick', login, 'Kick');
      else if (action === 'ban') await c.call('Ban', login, 'Ban');
      else if (action === 'unban') await c.call('UnBan', login);
      else if (action === 'black') await c.call('BlackList', login, 'Black');
      else if (action === 'unblack') await c.call('UnBlackList', login);
      else if (action === 'spec') await c.call('ForceSpectator', login, 1);
      else if (action === 'play') await c.call('ForceSpectator', login, 0);
      else throw Object.assign(new Error('unknown action'), { status: 400 });
    });
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Warn player (private chat message) ───────────────────────────
router.post('/:sid/players/warn', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { login, message } = req.body;
    if (!login || !message) return res.status(400).json({ error: 'login and message required' });

    const errors = [];
    let method = null;

    await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      // Try 1: Private message to specific login (TM2/MP/TMNF newer)
      if (!method) {
        try {
          await c.call('ChatSendServerMessageToLogin', String(message), String(login));
          method = 'private';
        } catch (e1) { errors.push('ChatSendServerMessageToLogin: ' + e1.message); }
      }

      // Try 2: Broadcast with colored warning prefix (ALWAYS works on TMNF)
      if (!method) {
        try {
          const msg = '$f00[ $fffWARN $f00→ $fff' + login + '$f00 ] $fff' + String(message);
          await c.call('ChatSendServerMessage', msg);
          method = 'broadcast';
        } catch (e2) { errors.push('ChatSendServerMessage: ' + e2.message); }
      }

      if (!method) {
        throw new Error('All warn methods failed: ' + errors.join(' | '));
      }
    });

    res.json({ ok: true, method, login });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'GBX connection failed' });
  }
});

// ── Banned & Blacklisted players ─────────────────────────────────
router.get('/:sid/players/banned', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const [banned, blacklisted] = await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      const safe = async (fn) => { try { return await fn(); } catch { return []; } };
      return Promise.all([
        safe(() => c.call('GetBanList', 500, 0)),
        safe(() => c.call('GetBlackList', 500, 0)),
      ]);
    });
    res.json({ ok: true, banned: banned || [], blacklisted: blacklisted || [] });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/players/banned/action', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { login, action } = req.body;
    if (!login) return res.status(400).json({ error: 'login required' });
    await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      if (action === 'unban') await c.call('UnBan', login);
      else if (action === 'unblack') await c.call('UnBlackList', login);
      else throw Object.assign(new Error('unknown action'), { status: 400 });
    });
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Maps ─────────────────────────────────────────────────────────
router.get('/:sid/maps', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const q = (req.query.search||'').toLowerCase();
    try {
      let maps = await withClient(s.host, s.port, s.rpcUser, s.rpcPass, c => callCompat(c, 'GetMapList', 700, 0));
      maps = maps.map(normalizeMap);
      if (q) maps = maps.filter(m => (m.Name||'').toLowerCase().includes(q)||(m.FileName||'').toLowerCase().includes(q));
      res.json(maps);
    } catch { res.json([]); }
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/maps/action', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { action, map_uid, map_file } = req.body;

    // Helper: remove a map — tries UID first (TM2/MP), then filename (TMNF)
    async function removeMap(c) {
      if (map_uid) {
        try { return await callCompat(c, 'RemoveMap', map_uid); } catch (_) {}
      }
      if (map_file) {
        // TMNF RemoveChallenge expects filename
        try { return await c.call('RemoveChallenge', map_file); } catch (_) {}
      }
      if (map_uid) {
        // Last resort: try as filename too (some servers store UID-like filenames)
        try { return await c.call('RemoveChallenge', map_uid); } catch (e) { throw e; }
      }
      throw new Error('No valid map identifier for remove');
    }

    await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      if (action === 'next') await callCompat(c, 'NextMap');
      else if (action === 'restart') await c.call('RestartMap');
      else if (action === 'jump') {
        // Try UID then filename for ChooseNextMap/Challenge
        try { await callCompat(c, 'ChooseNextMap', map_uid); }
        catch (_) { if (map_file) await c.call('ChooseNextChallenge', map_file); }
        await callCompat(c, 'NextMap');
      }
      else if (action === 'remove') await removeMap(c);
      else if (action === 'remove_file') {
        // Get filename from server before removing (more reliable than client-sent)
        let fileName = map_file || '';
        if (!fileName && map_uid) {
          const info = await callCompat(c, 'GetMapInfo', map_uid).catch(() => null)
            || (map_uid ? await c.call('GetChallengeInfo', map_uid).catch(() => null) : null);
          if (info) fileName = info.FileName || info.filename || '';
        }
        await removeMap(c);
        // Delete file from disk
        if (fileName) {
          const mapsBase = s.mapsPath || '';
          if (mapsBase) {
            try {
              const filePath = path.isAbsolute(fileName)
                ? fileName
                : path.join(mapsBase, fileName.replace(/\\/g, '/'));
              if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
            } catch (_) {}
          }
        }
      }
      else throw Object.assign(new Error('Unknown map action: ' + action), { status: 400 });
    });
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Server settings ───────────────────────────────────────────────
router.get('/:sid/server', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const data = await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      const out = {
        name: '',
        comment: '',
        password: '',
        password_spectator: '',
        max_players: null,
        max_specs: null,
        points_limit: null
      };

      try { out.name = await c.call('GetServerName'); } catch (_) {}
      try { out.comment = await c.call('GetServerComment'); } catch (_) {}

      try {
        const opts = await c.call('GetServerOptions');
        if (opts && typeof opts === 'object') {
          out.password = opts.Password || '';
          out.password_spectator = opts.PasswordForSpectator || '';
          out.max_players = opts.CurrentMaxPlayers ?? opts.MaxPlayers ?? null;
          out.max_specs = opts.CurrentMaxSpectators ?? opts.MaxSpectators ?? null;
        }
      } catch (_) {}

      try {
        const gi = await c.call('GetCurrentGameInfo');
        if (gi && typeof gi === 'object') {
          out.points_limit = gi.PointsLimit ?? gi.PointLimit ?? gi.LadderServerLimitMax ?? null;
          if (out.max_players == null && gi.MaxPlayers != null) out.max_players = gi.MaxPlayers;
          if (out.max_specs == null && gi.MaxSpectators != null) out.max_specs = gi.MaxSpectators;
        }
      } catch (_) {}

      return out;
    });
    res.json({ ok: true, settings: data });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/server', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const d = req.body || {};
    await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
      if (d.name != null) await c.call('SetServerName', d.name);
      if (d.comment != null) await c.call('SetServerComment', d.comment);
      if (d.password != null) await c.call('SetServerPassword', d.password);
      if (d.password_spectator != null) await c.call('SetServerPasswordForSpectator', d.password_spectator);
      if (d.max_players != null && d.max_players !== '') await c.call('SetMaxPlayers', Number(d.max_players));
      if (d.max_specs != null && d.max_specs !== '') await c.call('SetMaxSpectators', Number(d.max_specs));

      if (d.points_limit != null && d.points_limit !== '') {
        try {
          const gi = await c.call('GetCurrentGameInfo');
          if (gi && typeof gi === 'object') {
            gi.PointsLimit = Number(d.points_limit);
            await c.call('SetGameInfos', gi);
          }
        } catch (_) {}
      }

      if (d.chat) await c.call('ChatSendServerMessage', d.chat);
    });
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Dedicated.cfg helpers ─────────────────────────────────────────
function findDedicatedCfg(server) {
  // 1) Manual override — if set, use it DIRECTLY without any other check
  const manualPath = server.dedicatedCmds && server.dedicatedCmds.cfgPath;
  if (manualPath && manualPath.trim()) {
    const p = manualPath.trim();
    try { if (fs.existsSync(p) && fs.statSync(p).isFile()) return p; } catch {}
    // Still return it even if we can't stat — let the caller handle the read error
    return p;
  }

  const candidates = [];

  // Helper: add all standard cfg locations relative to a root dir
  // Searches for both dedicated.cfg AND dedicated_cfg.txt (TMNF variant)
  function addRoots(root) {
    if (!root) return;
    const names = ['dedicated.cfg', 'dedicated_cfg.txt', 'dedicated_cfg.xml',
                   path.join('UserData', 'Config', 'dedicated.cfg'),
                   path.join('UserData', 'Config', 'dedicated_cfg.txt'),
                   path.join('Config', 'dedicated.cfg'),
                   path.join('Config', 'dedicated_cfg.txt'),
                   path.join('config', 'dedicated.cfg'),
                   path.join('GameData', 'Config', 'dedicated.cfg'),
                   path.join('GameData', 'Config', 'dedicated_cfg.txt')];
    for (const n of names) candidates.push(path.join(root, n));
  }

  if (server.filesRoot) {
    addRoots(server.filesRoot);
    addRoots(path.dirname(server.filesRoot));
  }
  if (server.mapsPath) {
    const p2 = path.dirname(path.dirname(server.mapsPath));
    const p3 = path.dirname(p2);
    const p4 = path.dirname(p3);
    for (const r of [p2, p3, p4]) addRoots(r);
  }
  if (server.matchPath) {
    const r2 = path.dirname(path.dirname(server.matchPath));
    addRoots(r2); addRoots(path.dirname(r2));
  }

  const seen = new Set();
  for (const p of candidates) {
    if (!p || seen.has(p)) continue;
    seen.add(p);
    try { if (fs.existsSync(p) && fs.statSync(p).isFile()) return p; } catch {}
  }
  return null;
}

function xmlTag(tag) {
  // Returns regex to match <tag>value</tag> or <tag/>
  return new RegExp(`(<${tag}[^>]*>)([^<]*?)(</${tag}>)`, 'i');
}
function xmlGet(content, tag) {
  const m = content.match(xmlTag(tag));
  return m ? m[2].trim() : null;
}
function xmlSet(content, tag, value) {
  const esc = String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const rx = xmlTag(tag);
  if (rx.test(content)) return content.replace(rx, `$1${esc}$3`);
  // self-closing <tag/> → expand it
  const rxSelf = new RegExp(`<${tag}\\s*/>`, 'i');
  if (rxSelf.test(content)) return content.replace(rxSelf, `<${tag}>${esc}</${tag}>`);
  return content; // tag not found — skip
}

// Get password for a named authorization level
// Get password for a named authorization level
// Get/set password for a named authorization level
// cfg uses: <level><n>SuperAdmin</n><password>xxx</password></level>
function getAuthLevelPw(content, levelName) {
  var q = levelName.replace(/[-[\]{}()*+?.,\\^$|#]/g, '\\$&');
  var rx = new RegExp('<level>[\\s\\S]*?<(?:n|name)>[\\s]*' + q + '[\\s]*<\/(?:n|name)>[\\s\\S]*?<password>([^<]*)<\/password>', 'i');
  var m = content.match(rx);
  return m ? m[1].trim() : null;
}
function setAuthLevelPw(content, levelName, password) {
  var esc = String(password).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  var q = levelName.replace(/[-[\]{}()*+?.,\\^$|#]/g, '\\$&');
  var rx = new RegExp('(<level>[\\s\\S]*?<(?:n|name)>[\\s]*' + q + '[\\s]*<\/(?:n|name)>[\\s\\S]*?<password>)[^<]*(<\/password>)', 'i');
  return content.replace(rx, function(m, pre, post){ return pre + esc + post; });
}
function extractSection(content, tag) {
  var m = content.match(new RegExp('<' + tag + '>([\\s\\S]*?)<\/' + tag + '>', 'i'));
  return m ? m[1] : '';
}

function parseDedicatedCfg(content) {
  const out = {};
  var soBlock = extractSection(content, 'server_options');
  var scBlock = extractSection(content, 'system_config');
  var msBlock = extractSection(content, 'masterserver_account');

  // server_options — all editable fields
  const soFields = [
    'name','comment','hide_server',
    'max_players','password','max_spectators','password_spectator',
    'ladder_mode','ladder_serverlimit_min','ladder_serverlimit_max',
    'enable_p2p_upload','enable_p2p_download',
    'callvote_timeout','callvote_ratio',
    'allow_challenge_download','allow_map_download',
    'autosave_replays','autosave_validation_replays',
    'referee_password','referee_validation_mode','use_changing_validation_seed',
  ];
  for (const f of soFields) {
    const v = xmlGet(soBlock || content, f);
    if (v !== null) out[f] = v;
  }

  // system_config
  const scFields = [
    'connection_uploadrate','connection_downloadrate',
    'server_port','server_p2p_port','client_port',
    'xmlrpc_port','xmlrpc_allowremote',
    'packmask','allow_spectator_relays','p2p_cache_size',
    'force_ip_address','use_nat_upnp','use_proxy',
  ];
  for (const f of scFields) {
    const v = xmlGet(scBlock || content, f);
    if (v !== null) out[f] = v;
  }

  // masterserver_account
  if (msBlock) {
    const msFields = { ms_login:'login', ms_password:'password', ms_validation_key:'validation_key' };
    for (const [key, tag] of Object.entries(msFields)) {
      const v = xmlGet(msBlock, tag);
      if (v !== null) out[key] = v;
    }
  }

  // auth level passwords
  for (const lvl of ['SuperAdmin','Admin','User']) {
    const pw = getAuthLevelPw(content, lvl);
    if (pw !== null) out['auth_'+lvl.toLowerCase()+'_password'] = pw;
  }
  return out;
}

function patchDedicatedCfg(content, updates) {
  let c = content;
  for (const [key, value] of Object.entries(updates)) {
    if (value == null || value === '') continue;
    if (key === 'auth_superadmin_password') { c = setAuthLevelPw(c, 'SuperAdmin', value); continue; }
    if (key === 'auth_admin_password')      { c = setAuthLevelPw(c, 'Admin', value);      continue; }
    if (key === 'auth_user_password')       { c = setAuthLevelPw(c, 'User', value);        continue; }
    // masterserver fields — scope to masterserver_account block
    if (key === 'ms_login')     { c = xmlSet(c, 'login', value);          continue; }
    if (key === 'ms_password')  { c = xmlSet(c, 'password', value);       continue; }
    if (key === 'ms_validation_key') { c = xmlSet(c, 'validation_key', value); continue; }
    // everything else — direct tag replacement
    c = xmlSet(c, key, value);
  }
  return c;
}

// POST /:sid/servercfg/path — save cfgPath (accessible to all logged-in users)
router.post('/:sid/servercfg/path', (req, res) => {
  try {
    getServerForUser(req, req.params.sid); // auth check
    const { cfgPath } = req.body;
    if (!cfgPath || !cfgPath.trim()) return res.status(400).json({ error: 'cfgPath required' });

    const server = db.servers.findById(Number(req.params.sid));
    if (!server) return res.status(404).json({ error: 'Server not found' });

    // Merge cfgPath into existing dedicatedCmds and do a full update
    const dc = Object.assign({}, server.dedicatedCmds || {}, { cfgPath: cfgPath.trim() });
    db.servers.update(server.id, {
      label: server.label,
      game: server.game,
      host: server.host,
      port: server.port,
      rpcUser: server.rpcUser,
      rpcPass: server.rpcPass,
      mapsPath: server.mapsPath,
      matchPath: server.matchPath,
      filesRoot: server.filesRoot,
      dedicatedCmds: dc,
      pyplanetCmds: server.pyplanetCmds || {},
      controllerType: server.controllerType || 'pyplanet',
      controllerCmds: server.controllerCmds || {},
      backupConfig: server.backupConfig || {},
      controllerEnabled: server.controllerEnabled || false,
    });

    // Verify it was saved
    const verify = db.servers.findById(server.id);
    const saved = verify && verify.dedicatedCmds && verify.dedicatedCmds.cfgPath;
    res.json({ ok: true, cfgPath: cfgPath.trim(), saved: saved || 'unknown' });
  } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});

// GET /:sid/servercfg — read dedicated.cfg
router.get('/:sid/servercfg', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const manualPath = s.dedicatedCmds && s.dedicatedCmds.cfgPath && s.dedicatedCmds.cfgPath.trim();
    const hasConfig = !!(manualPath || s.filesRoot || s.mapsPath || s.matchPath);

    if (!hasConfig) {
      return res.json({ ok: false, notConfigured: true, storedPath: '',
        error: 'No path configured.',
        hint: 'Enter the full path to your cfg file below.' });
    }

    const cfgPath = findDedicatedCfg(s);

    if (!cfgPath) {
      return res.json({
        ok: false,
        storedPath: manualPath || '',  // always return what was stored
        error: 'File not found.',
        hint: 'Check the path is correct. Your file: ' + (manualPath || 'not set'),
        searched: manualPath ? [manualPath] : []
      });
    }

    try {
      const content = fs.readFileSync(cfgPath, 'utf8');
      res.json({ ok: true, path: cfgPath, storedPath: manualPath || cfgPath, content, parsed: parseDedicatedCfg(content) });
    } catch (readErr) {
      res.json({ ok: false, storedPath: cfgPath, error: 'Cannot read file: ' + readErr.message });
    }
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// POST /:sid/servercfg — patch dedicated.cfg / dedicated_cfg.txt
router.post('/:sid/servercfg', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const cfgPath = findDedicatedCfg(s);
    if (!cfgPath) return res.status(404).json({ error: 'Config file not found. Set the path first in Settings.' });
    if (!fs.existsSync(cfgPath)) return res.status(404).json({ error: 'File not found at: ' + cfgPath });
    const content = fs.readFileSync(cfgPath, 'utf8');
    const backupPath = cfgPath + '.bak-' + new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
    fs.writeFileSync(backupPath, content);
    const patched = patchDedicatedCfg(content, req.body || {});
    fs.writeFileSync(cfgPath, patched, 'utf8');
    res.json({ ok: true, path: cfgPath, backup: backupPath });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Dedicated ────────────────────────────────────────────────────
router.all('/:sid/dedicated/:action', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { action } = req.params;

    // cfg is handled by its own GET/POST routes above — skip here
    if (action === 'cfg') return res.status(400).json({ error: 'Use /api/:sid/servercfg instead of /dedicated/cfg' });

    const cmds = s.dedicatedCmds || {};

    if (action === 'logs') {
      const logPath = resolveLogPath(s, cmds.log);
      if (!logPath) return res.status(400).json({ error: 'Log path not configured', tip: 'Set dedicated_cmds.log in Admin → Servers → dedicated_cmds' });
      res.set({'Cache-Control':'no-store,no-cache','Pragma':'no-cache'});
      const lines = fs.readFileSync(logPath, 'utf8').split('\n').slice(-500).join('\n');
      return res.json({ log: lines, path: logPath });
    }
    if (!['start','stop','restart','status'].includes(action))
      return res.status(400).json({ error: `Unknown dedicated action: "${action}". Valid: start, stop, restart, status, logs` });
    if (!cmds[action]) return res.status(400).json({ error: `Command "${action}" not configured`, tip: 'Set dedicated_cmds in Admin → Servers' });
    const output = await withServerActionLock(s.id, 'dedicated', async () => runCmd(cmds[action]));
    res.json({ output });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── PyPlanet ─────────────────────────────────────────────────────
router.all('/:sid/pyplanet/:action', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { action } = req.params;
    const cmds = s.pyplanetCmds || {};

    if (action === 'logs') {
      const logPath = resolveLogPath(s, cmds.logfile);
      if (!logPath) return res.status(400).json({ error: 'log not found', tried: cmds.logfile || '(not configured)', tip: 'Set pyplanet_cmds.logfile in Admin → Servers' });
      res.set({'Cache-Control':'no-store,no-cache','Pragma':'no-cache'});
      const lines = fs.readFileSync(logPath, 'utf8').split('\n').slice(-500).join('\n');
      return res.json({ output: lines, path: logPath });
    }
    if (!['start','stop','restart','status'].includes(action))
      return res.status(400).json({ error: 'unknown action' });
    const cmd = cmds[action] || (cmds.script ? `${cmds.script} ${action}` : null);
    if (!cmd) return res.status(400).json({ error: 'pyplanet not configured' });
    res.json({ output: await runCmd(cmd) });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Console ───────────────────────────────────────────────────────
router.get('/:sid/console/logs', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const logPath = resolveLogPath(s, (s.dedicatedCmds||{}).log);
    if (!logPath) return res.status(400).json({ error: 'log not found', tried: (s.dedicatedCmds||{}).log || '(not configured)' });
    res.set({'Cache-Control':'no-store,no-cache','Pragma':'no-cache'});
    const lines = fs.readFileSync(logPath, 'utf8').split('\n').slice(-600).join('\n');
    res.json({ log: lines, path: logPath });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/console/chat', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: 'message required' });
    await withClient(s.host, s.port, s.rpcUser, s.rpcPass, c => c.call('ChatSendServerMessage', message));
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// GET /api/:sid/chat/lines — live chat lines from TM server
router.get('/:sid/chat/lines', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const count = Math.min(parseInt(req.query.count)||50, 200);
    res.set({'Cache-Control':'no-store,no-cache'});
    try {
      const lines = await withClient(s.host, s.port, s.rpcUser, s.rpcPass, async c => {
        // GetChatLines(MaxNbLines, ServerSideOnly)
        const raw = await c.call('GetChatLines');
        return Array.isArray(raw) ? raw : [];
      });
      res.json({ ok: true, lines: lines.slice(-count) });
    } catch (e) {
      res.json({ ok: false, lines: [], error: e.message });
    }
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Credentials (per server) ──────────────────────────────────────
router.get('/:sid/credentials', (req, res) => {
  try {
    const sid = Number(req.params.sid);
    const servers = db.servers.findAll();
    const serverMap = {};
    servers.forEach(function(s){ serverMap[Number(s.id)] = s.label || ('Server #' + s.id); });
    const seen = new Set();
    const creds = [].concat(db.credentials.findGlobal(), db.credentials.findByServer(sid)).filter(function(c){
      if (seen.has(c.id)) return false;
      seen.add(c.id);
      return true;
    }).map(function(c){
      return {
        ...c,
        serverLabel: Number(c.serverId) > 0 ? (serverMap[Number(c.serverId)] || ('Server #' + c.serverId)) : 'Global'
      };
    });
    res.json(creds);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── File System ───────────────────────────────────────────────────
router.get('/:sid/fs/list', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const base = fsBase(s, req.query.root||'maps');
    const target = safePath(base, req.query.path||'');
    if (!fs.existsSync(target)) return res.json({ path: req.query.path||'', entries: [], root: base });
    if (!fs.statSync(target).isDirectory()) return res.status(400).json({ error: 'not a directory' });
    const entries = fs.readdirSync(target).sort().map(name => {
      const p = path.join(target, name);
      try { const st = fs.statSync(p); return { name, is_dir: st.isDirectory(), size: st.isFile()?st.size:null, mtime: Math.floor(st.mtimeMs/1000) }; }
      catch { return { name, is_dir: false, size: null, mtime: null }; }
    });
    res.json({ path: req.query.path||'', root: base, entries });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.get('/:sid/fs/read', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const target = safePath(fsBase(s, req.query.root||'maps'), req.query.path||'');
    if (!fs.existsSync(target)||!fs.statSync(target).isFile()) return res.status(404).json({ error: 'not found' });
    res.json({ ok: true, content: fs.readFileSync(target, 'utf8') });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.get('/:sid/fs/download', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const root = req.query.root || 'maps';
    const rel = req.query.path || '';
    const target = safePath(fsBase(s, root), rel);
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return res.status(404).json({ error: 'not found' });
    return res.download(target, path.basename(target));
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.get('/:sid/fs/archive', async (req, res) => {
  let archivePath = '';
  try {
    const s = getServerForUser(req, req.params.sid);
    const root = req.query.root || 'maps';
    const rel = String(req.query.path || '').replace(/\\/g, '/').replace(/^\/+/, '');
    const base = fsBase(s, root);
    const target = safePath(base, rel);
    if (!fs.existsSync(target)) return res.status(404).json({ error: 'not found' });
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
    const zipBase = path.basename(rel || path.basename(target) || 'archive').replace(/\.zip$/i, '');
    archivePath = path.join(UPLOAD_DIR, `${uuidv4()}_${zipBase}.zip`);
    const escapedBase = String(base).replace(/"/g, '\"');
    const escapedRel = String(rel || path.basename(target)).replace(/"/g, '\"');
    const out = await runCmd(`cd "${escapedBase}" && zip -qry "${archivePath}" "${escapedRel}"`, 120000);
    if (!fs.existsSync(archivePath)) return res.status(500).json({ error: out || 'Failed to create zip archive' });
    return res.download(archivePath, `${zipBase}.zip`, () => { try { fs.unlinkSync(archivePath); } catch {} });
  } catch (err) {
    if (archivePath) { try { fs.unlinkSync(archivePath); } catch {} }
    res.status(err.status||500).json({ error: err.message });
  }
});

router.post('/:sid/fs/save', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const target = safePath(fsBase(s, req.body.root||'maps'), req.body.path||'');
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, req.body.content||'', 'utf8');
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/fs/delete', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const target = safePath(fsBase(s, req.body.root||'maps'), req.body.path||'');
    if (fs.existsSync(target)) {
      if (fs.statSync(target).isDirectory()) fs.rmSync(target, { recursive: true });
      else fs.unlinkSync(target);
    }
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/fs/mkdir', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    fs.mkdirSync(safePath(fsBase(s, req.body.root||'maps'), req.body.path||''), { recursive: true });
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

const upload = multer({ dest: UPLOAD_DIR });
router.post('/:sid/fs/touch', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const target = safePath(fsBase(s, req.body.root||'maps'), req.body.path||'');
    fs.mkdirSync(path.dirname(target), { recursive: true });
    if (!fs.existsSync(target)) fs.writeFileSync(target, '', 'utf8');
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/fs/rename', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const src = safePath(fsBase(s, req.body.root||'maps'), req.body.path||'');
    const dest = safePath(fsBase(s, req.body.root||'maps'), path.join(path.dirname(req.body.path||''), req.body.name||''));
    fs.renameSync(src, dest);
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/fs/move', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const src = safePath(fsBase(s, req.body.root||'maps'), req.body.path||'');
    const name = path.basename(req.body.path||'');
    const dest = safePath(fsBase(s, req.body.root||'maps'), path.join(req.body.dest||'', name));
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.renameSync(src, dest);
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/fs/upload', upload.array('files', 500), (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const files = req.files || [];
    if (!files.length) return res.status(400).json({ error: 'file required' });
    const destDir = safePath(fsBase(s, req.query.root||'maps'), req.query.path||'');
    fs.mkdirSync(destDir, { recursive: true });
    const paths = Array.isArray(req.body.paths) ? req.body.paths : (req.body.paths ? [req.body.paths] : []);
    const saved = [];
    files.forEach((file, i) => {
      const rel = String(paths[i] || file.originalname || '').replace(/\\/g, '/').replace(/^\/+/, '');
      const dest = safePath(destDir, rel || file.originalname);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(file.path, dest);
      fs.unlinkSync(file.path);
      saved.push(path.relative(destDir, dest));
    });
    res.json({ ok: true, files: saved });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});



// ── MatchSettings Assistant ─────────────────────────────────────
router.get('/:sid/matchassistant/bootstrap', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const mapsBase = fsBase(s, 'maps');
    const matchBase = fsBase(s, 'match');
    const folders = listFoldersRecursive(mapsBase, '').map(v => v || '.');
    const matchFiles = listFilesRecursive(matchBase, '', true, /\.txt$/i, []);
    const startCmd = (s.dedicatedCmds && s.dedicatedCmds.start) || '';
    const startupMatchFile = (() => { const m = String(startCmd).match(/\/game_settings=([^\s"']+)/i); return m ? matchSettingStartupName(m[1]) : ''; })();
    res.json({ ok:true, folders, matchFiles, startupMatchFile, defaultMapTarget:'Challenges', paths:{ mapsBase, matchBase, tmRoot: inferTmRoot(s) } });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.get('/:sid/matchassistant/list-maps', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const maps = listMapsRecursive(fsBase(s, 'maps'), req.query.dir === '.' ? '' : (req.query.dir||''), String(req.query.recursive||'0') === '1');
    res.json({ ok:true, maps });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.get('/:sid/matchassistant/read', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const file = String(req.query.file||'');
    const target = safePath(fsBase(s, 'match'), file);
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return res.status(404).json({ error:'file not found' });
    const content = fs.readFileSync(target, 'utf8');
    const parsed = parseMatchSettingsXml(content);
    res.json({ ok:true, filename:path.basename(file), ...parsed, xml:content });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/matchassistant/save', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    let filename = String(req.body.filename||'matchsettings.txt').trim();
    if (!/\.txt$/i.test(filename)) filename += '.txt';
    const target = safePath(fsBase(s, 'match'), filename);
    fs.mkdirSync(path.dirname(target), { recursive:true });
    fs.writeFileSync(target, String(req.body.xml||''), 'utf8');
    let startupUpdated = false;
    if (req.body.setStartup) {
      const relName = filename.replace(/\\/g,'/');
      const server = db.servers.findById(Number(req.params.sid));
      const dc = Object.assign({}, server.dedicatedCmds || {});
      if (dc.start) dc.start = patchStartupCommand(dc.start, relName);
      db.servers.update(server.id, {
        label: server.label, game: server.game, host: server.host, port: server.port, rpcUser: server.rpcUser, rpcPass: server.rpcPass,
        mapsPath: server.mapsPath, matchPath: server.matchPath, filesRoot: server.filesRoot, dedicatedCmds: dc, pyplanetCmds: server.pyplanetCmds || {},
        controllerType: server.controllerType || 'pyplanet', controllerCmds: server.controllerCmds || {}, backupConfig: server.backupConfig || {}, controllerEnabled: server.controllerEnabled || false,
      });
      const scriptPath = inferTmRoot(server) && path.join(inferTmRoot(server), 'start.sh');
      try {
        if (scriptPath && fs.existsSync(scriptPath) && fs.statSync(scriptPath).isFile()) {
          const content = fs.readFileSync(scriptPath, 'utf8');
          fs.writeFileSync(scriptPath, patchStartupScriptContent(content, relName), 'utf8');
        }
      } catch {}
      startupUpdated = true;
    }
    res.json({ ok:true, filename, path:target, startupUpdated });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/matchassistant/set-start', (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const relName = String(req.body.filename||'').trim();
    if (!relName) return res.status(400).json({ error:'filename required' });
    const server = db.servers.findById(Number(req.params.sid));
    const dc = Object.assign({}, server.dedicatedCmds || {});
    if (dc.start) dc.start = patchStartupCommand(dc.start, relName);
    db.servers.update(server.id, {
      label: server.label, game: server.game, host: server.host, port: server.port, rpcUser: server.rpcUser, rpcPass: server.rpcPass,
      mapsPath: server.mapsPath, matchPath: server.matchPath, filesRoot: server.filesRoot, dedicatedCmds: dc, pyplanetCmds: server.pyplanetCmds || {},
      controllerType: server.controllerType || 'pyplanet', controllerCmds: server.controllerCmds || {}, backupConfig: server.backupConfig || {}, controllerEnabled: server.controllerEnabled || false,
    });
    const scriptPath = inferTmRoot(server) && path.join(inferTmRoot(server), 'start.sh');
    try {
      if (scriptPath && fs.existsSync(scriptPath) && fs.statSync(scriptPath).isFile()) {
        const content = fs.readFileSync(scriptPath, 'utf8');
        fs.writeFileSync(scriptPath, patchStartupScriptContent(content, relName), 'utf8');
      }
    } catch {}
    res.json({ ok:true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Backups ───────────────────────────────────────────────────────
router.get('/:sid/backups', async (req, res) => {
  try {
    const server = getServerForUser(req, req.params.sid);
    const cfg = backupCfg(server);
    const local = fs.readdirSync(bdir(req.params.sid)).filter(f=>f.endsWith('.tar.gz')).sort().reverse().map(name => {
      const p = path.join(bdir(req.params.sid), name); const st = fs.statSync(p);
      return { id:'local:'+name, source:'local', name, size:st.size, created_at:st.mtime.toISOString(), download_url:`/api/${req.params.sid}/backups/download/local/${encodeURIComponent(name)}` };
    });
    const s3 = await listS3Backups(server).catch(() => []);
    res.json({
      items: [...local, ...s3].sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))),
      config: cfg,
      schedulePreview: nextSchedulePreview(cfg.schedule),
      localCount: local.length,
      s3Count: s3.length
    });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/backups', async (req, res) => {
  try {
    const server = getServerForUser(req, req.params.sid);
    const result = await makeBackup(server);
    res.json(result);
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.get('/:sid/backups/download/:source/:name', async (req, res) => {
  try {
    const server = getServerForUser(req, req.params.sid);
    const source = req.params.source || 'local';
    const name = req.params.name;
    if (source === 's3') return await streamS3Backup(server, name, res);
    const d = path.resolve(bdir(req.params.sid));
    const p = path.resolve(path.join(d, name));
    if (!p.startsWith(d)||!fs.existsSync(p)) return res.status(404).json({ error: 'not found' });
    res.download(p);
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.post('/:sid/backups/restore', async (req, res) => {
  try {
    const server = getServerForUser(req, req.params.sid);
    const id = req.body.id || req.body.name;
    const source = (req.body.source || (String(id).startsWith('s3:') ? 's3' : 'local')).replace(':','');
    const name = String(id || '').replace(/^local:|^s3:/, '');
    if (!name) return res.status(400).json({ error: 'id required' });
    const result = await restoreBackup(server, name, source);
    res.json(result);
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

router.delete('/:sid/backups/:source/:name', requireAdmin, async (req, res) => {
  try {
    const server = getServerForUser(req, req.params.sid);
    const source = req.params.source || 'local';
    const name = req.params.name;
    if (source === 's3') {
      await deleteS3Backup(server, name);
    } else {
      const d = path.resolve(bdir(req.params.sid));
      const p = path.resolve(path.join(d,name));
      if (p.startsWith(d)&&fs.existsSync(p)) fs.unlinkSync(p);
    }
    res.json({ ok: true });
  } catch (err) { res.status(err.status||500).json({ error: err.message }); }
});

// ── Installer ─────────────────────────────────────────────────────
const instUpload = multer({ dest: UPLOAD_DIR });
router.post('/installer/upload', requireAdmin, instUpload.single('file'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'file required' });
    const name = req.file.originalname.toLowerCase();
    if (!name.endsWith('.zip')&&!name.endsWith('.tar.gz')&&!name.endsWith('.tgz'))
      return res.status(400).json({ error: 'only .zip/.tar.gz/.tgz allowed' });
    const token = `inst_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const dest = path.join(UPLOAD_DIR, `${token}_${req.file.originalname}`);
    fs.copyFileSync(req.file.path, dest);
    fs.unlinkSync(req.file.path);
    res.json({ ok: true, token, stored_as: path.basename(dest) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/installer/install', requireAdmin, async (req, res) => {
  try {
    const { token, label, game, host, port, rpcUser, rpcPass, folder } = req.body;
    if (!token) return res.status(400).json({ error: 'token required' });
    if (!port) return res.status(400).json({ error: 'port required' });
    const files = fs.readdirSync(UPLOAD_DIR).filter(f=>f.startsWith(token+'_'));
    if (!files.length) return res.status(404).json({ error: 'upload not found' });
    const arc = path.join(UPLOAD_DIR, files[0]);
    const installRoot = process.env.TMCONTROL_INSTALL_ROOT||'/srv/tmcontrol';
    const folderName = ((folder||label||`srv-${Date.now()}`).replace(/[^a-z0-9-]/gi,'-').slice(0,32));
    const destDir = path.resolve(path.join(installRoot, folderName));
    fs.mkdirSync(destDir, { recursive: true });
    if (arc.endsWith('.zip')) await runCmd(`unzip -o "${arc}" -d "${destDir}"`);
    else await runCmd(`tar xzf "${arc}" -C "${destDir}"`);
    fs.unlinkSync(arc);
    const id = db.servers.create({ label:label||'New Server', game:game||'tm', host:host||'127.0.0.1', port:Number(port), rpcUser:rpcUser||'SuperAdmin', rpcPass:rpcPass||'', filesRoot:destDir, mapsPath:'', matchPath:'', dedicatedCmds:{}, pyplanetCmds:{} });
    for (const u of db.users.findAll()) {
      if (u.role==='admin') { const sids=db.users.getServers(u.id); if(!sids.includes(id)) db.users.setServers(u.id,[...sids,id]); }
    }
    res.json({ ok: true, id, folder: destDir });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── Controller (PyPlanet / UASECO / ManiaControl) ───────────────────────────

function isTmnfGame(game) {
  const g = String(game || '').toLowerCase();
  return g === 'tm' || g.includes('tmnf') || g.includes('tmf') || g.includes('nations forever');
}

function isControllerEnabledForUser(server, req) {
  if ((req.session && req.session.role) === 'admin') return true;
  if (isTmnfGame(server.game)) return true;
  return !!server.controllerEnabled;
}

function getAllowedControllerTypes(server, req) {
  if (isTmnfGame(server.game)) return ['xaseco'];
  if ((req.session && req.session.role) === 'admin') return ['pyplanet','uaseco','maniacontrol','minicontrol','nextcontrol','evosc'];
  return isControllerEnabledForUser(server, req) ? ['pyplanet','uaseco','maniacontrol','minicontrol','nextcontrol','evosc'] : [];
}

function sanitizeControllerTypeForServer(server, req, type) {
  const allowed = getAllowedControllerTypes(server, req);
  const wanted = String(type || '').trim().toLowerCase();
  if (allowed.includes(wanted)) return wanted;
  return allowed[0] || null;
}

const CONTROLLER_DEFAULTS = {
  pyplanet: {
    start:   'sudo -n {dir}/pyplanet/py.sh start',
    stop:    'sudo -n {dir}/pyplanet/py.sh stop',
    restart: 'sudo -n {dir}/pyplanet/py.sh restart',
    status:  'sudo -n {dir}/pyplanet/py.sh status',
    update:  'pip3 install --upgrade pyplanet',
    install: 'pip3 install pyplanet && echo "PyPlanet installed"',
    logfile: '{dir}/pyplanet/logs/pyplanet.log',
    label: 'PyPlanet',
    links: [
      { label: '🌐 pypla.net', url: 'https://pypla.net/' },
      { label: '📦 GitHub', url: 'https://github.com/PyPlanet/PyPlanet' },
      { label: '💬 Discord', url: 'https://discord.gg/NnbMAtG' },
      { label: '📖 Docs', url: 'https://pypla.net/en/latest/' },
    ],
  },
  uaseco: {
    start:   '([ -f {dir}/uaseco/uaseco.sh ] && {dir}/uaseco/uaseco.sh start) || (cd {dir}/uaseco && php RunServer.php > /dev/null 2>&1 &)',
    stop:    '([ -f {dir}/uaseco/uaseco.sh ] && {dir}/uaseco/uaseco.sh stop) || pkill -f "php.*RunServer" 2>&1 || true',
    restart: '([ -f {dir}/uaseco/uaseco.sh ] && {dir}/uaseco/uaseco.sh restart) || (pkill -f "php.*RunServer" 2>/dev/null; sleep 1; cd {dir}/uaseco && php RunServer.php > /dev/null 2>&1 &)',
    status:  '([ -f {dir}/uaseco/uaseco.sh ] && {dir}/uaseco/uaseco.sh status) || (pgrep -f "php.*RunServer" > /dev/null && echo "UASECO running" || echo "UASECO stopped")',
    update:  'cd {dir}/uaseco && git pull',
    install: 'mkdir -p {dir}/uaseco && wget -q "http://cdn-http.tmcdn.de/api/cdn/8ce22afb/UASECO-0.9.6_2019-03-02.zip" -O /tmp/uaseco.zip && unzip -o /tmp/uaseco.zip -d /tmp/uaseco_tmp && cp -rf /tmp/uaseco_tmp/*/* {dir}/uaseco/ && rm -rf /tmp/uaseco_tmp /tmp/uaseco.zip && echo "UASECO installed to {dir}/uaseco"',
    logfile: '{dir}/uaseco/logs/uaseco.log',
    label: 'UASECO',
    links: [
      { label: '🌐 uaseco.org', url: 'https://www.uaseco.org/' },
      { label: '📦 GitHub', url: 'https://github.com/undeflabs/UASECO-Maniaplanet' },
      { label: '📖 Install Guide', url: 'https://www.uaseco.org/documentation/installation.php' },
    ],
  },
  maniacontrol: {
    start:   'sudo -n {dir}/ManiaControl/ManiaControl.sh start',
    stop:    'sudo -n {dir}/ManiaControl/ManiaControl.sh stop',
    restart: 'sudo -n {dir}/ManiaControl/ManiaControl.sh restart',
    status:  'sudo -n {dir}/ManiaControl/ManiaControl.sh status',
    update:  'cd {dir}/ManiaControl && git pull',
    install: 'mkdir -p {dir}/ManiaControl && wget -q "http://cdn-http.tmcdn.de/api/cdn/9f08285f/ManiaControl_beta_0-258.zip" -O /tmp/maniacontrol.zip && unzip -o /tmp/maniacontrol.zip -d /tmp/mc_tmp && cp -rf /tmp/mc_tmp/*/* {dir}/ManiaControl/ && rm -rf /tmp/mc_tmp /tmp/maniacontrol.zip && echo "ManiaControl installed to {dir}/ManiaControl"',
    logfile: '{dir}/ManiaControl/logs/ManiaControl.log',
    label: 'ManiaControl',
    links: [
      { label: '📦 GitHub', url: 'https://github.com/ManiaControl/ManiaControl' },
      { label: '📖 Wiki', url: 'https://github.com/ManiaControl/ManiaControl/wiki' },
      { label: '🚀 Releases', url: 'https://github.com/ManiaControl/ManiaControl/releases' },
    ],
  },

  nextcontrol: {
    start:   'cd {dir}/nextcontrol && (npm start 2>&1 || node index.js 2>&1)',
    stop:    'pkill -f "node.*nextcontrol" 2>/dev/null || pkill -f "node.*server.js" 2>/dev/null || true',
    restart: 'pkill -f "node.*nextcontrol" 2>/dev/null || pkill -f "node.*server.js" 2>/dev/null || true; sleep 1; cd {dir}/nextcontrol && (npm start > /dev/null 2>&1 & || node index.js > /dev/null 2>&1 &)',
    status:  'pgrep -af "node.*nextcontrol|node.*server.js" || echo "NextControl stopped"',
    update:  'cd {dir}/nextcontrol && git pull && npm install',
    install: 'mkdir -p {dir}/nextcontrol && rm -rf /tmp/nextcontrol-tmp && git clone --depth 1 https://github.com/dassschaf/nextcontrol /tmp/nextcontrol-tmp && cp -rf /tmp/nextcontrol-tmp/. {dir}/nextcontrol/ && rm -rf /tmp/nextcontrol-tmp && cd {dir}/nextcontrol && npm install && echo "NextControl installed to {dir}/nextcontrol"',
    logfile: '{dir}/nextcontrol/logs/nextcontrol.log',
    label: 'NextControl',
    links: [
      { label: '📦 GitHub', url: 'https://github.com/dassschaf/nextcontrol' }
    ],
  },
  evosc: {
    start:   'cd {dir}/evosc && ([ -f ./index.php ] && php index.php 2>&1 || echo "index.php not found")',
    stop:    'pkill -f "php.*evosc" 2>/dev/null || pkill -f "php.*index.php" 2>/dev/null || true',
    restart: 'pkill -f "php.*evosc" 2>/dev/null || pkill -f "php.*index.php" 2>/dev/null || true; sleep 1; cd {dir}/evosc && ([ -f ./index.php ] && php index.php > /dev/null 2>&1 & || true)',
    status:  'pgrep -af "php.*evosc|php.*index.php" || echo "EvoSC stopped"',
    update:  'cd {dir}/evosc && git pull && (composer install --no-interaction || true)',
    install: 'mkdir -p {dir}/evosc && wget -q "http://cdn-http.tmcdn.de/api/cdn/0f73e285/EvoSC-master.zip" -O /tmp/evosc.zip && rm -rf /tmp/evosc_tmp && unzip -o /tmp/evosc.zip -d /tmp/evosc_tmp && sh -lc "cp -rf /tmp/evosc_tmp/*/* {dir}/evosc/ 2>/dev/null || cp -rf /tmp/evosc_tmp/* {dir}/evosc/" && rm -rf /tmp/evosc_tmp /tmp/evosc.zip && echo "EvoSC installed to {dir}/evosc"',
    logfile: '{dir}/evosc/logs/evosc.log',
    label: 'EvoSC',
    links: [
      { label: '📦 GitHub', url: 'https://github.com/EvoEsports/EvoSC' }
    ],
  },
  xaseco: {
    start:   'sudo -n {dir}/xaseco/xaseco.sh start',
    stop:    'sudo -n {dir}/xaseco/xaseco.sh stop',
    restart: 'sudo -n {dir}/xaseco/xaseco.sh restart',
    status:  'sudo -n {dir}/xaseco/xaseco.sh status',
    update:  'cd {dir}/xaseco && wget -q "http://cdn-http.tmcdn.de/api/cdn/c6d47125/xaseco1.16-php7-dev.zip" -O /tmp/xaseco.zip && unzip -o /tmp/xaseco.zip -d /tmp/xaseco_tmp && cp -rf /tmp/xaseco_tmp/*/* {dir}/xaseco/ && rm -rf /tmp/xaseco_tmp /tmp/xaseco.zip && echo "XASECO updated"',
    install: 'mkdir -p {dir}/xaseco && wget -q "http://cdn-http.tmcdn.de/api/cdn/c6d47125/xaseco1.16-php7-dev.zip" -O /tmp/xaseco.zip && unzip -o /tmp/xaseco.zip -d /tmp/xaseco_tmp && cp -rf /tmp/xaseco_tmp/*/* {dir}/xaseco/ && rm -rf /tmp/xaseco_tmp /tmp/xaseco.zip && echo "XASECO installed to {dir}/xaseco"',
    logfile: '{dir}/xaseco/xaseco.log',
    label: 'XASECO',
    links: [
      { label: '🌐 xaseco.org', url: 'https://www.xaseco.org/' },
      { label: '📦 Download', url: 'http://cdn-http.tmcdn.de/api/cdn/c6d47125/xaseco1.16-php7-dev.zip' },
      { label: '📖 Forum', url: 'https://forum.maniaplanet.com/viewforum.php?f=466' },
    ],
  },
  minicontrol: {
    start:   'sudo -n {dir}/minicontrol/minicontrol.sh start',
    stop:    'sudo -n {dir}/minicontrol/minicontrol.sh stop',
    restart: 'sudo -n {dir}/minicontrol/minicontrol.sh restart',
    status:  'sudo -n {dir}/minicontrol/minicontrol.sh status',
    update:  'cd {dir}/minicontrol && git pull && npm install',
    install: 'mkdir -p {dir}/minicontrol && wget -q "http://cdn-http.tmcdn.de/api/cdn/810b2d90/minicontrol-main.zip" -O /tmp/minicontrol.zip && unzip -o /tmp/minicontrol.zip -d /tmp/mc2_tmp && cp -rf /tmp/mc2_tmp/*/* {dir}/minicontrol/ && rm -rf /tmp/mc2_tmp /tmp/minicontrol.zip && cd {dir}/minicontrol && npm install && echo "MINIcontrol installed to {dir}/minicontrol"',
    logfile: '{dir}/minicontrol/logs/minicontrol.log',
    label: 'MINIcontrol',
    links: [
      { label: '📦 GitHub', url: 'https://github.com/EvoEsports/minicontrol' },
      { label: '🚀 Releases', url: 'https://github.com/EvoEsports/minicontrol/releases' },
    ],
  },
};

function getControllerCmd(s, action) {
  const type = s.controllerType || 'pyplanet';
  const cmds = s.controllerCmds || {};
  // User-defined controllerCmds takes priority
  if (cmds[action]) return cmds[action];

  // For pyplanet, fall back to pyplanetCmds (old field from servers.json import)
  if (type === 'pyplanet' && s.pyplanetCmds) {
    const pp = s.pyplanetCmds;
    if (action === 'logfile' && pp.logfile) return pp.logfile;
    if (action === 'start'   && pp.script)  return pp.script + ' start';
    if (action === 'stop'    && pp.script)  return pp.script + ' stop';
    if (action === 'restart' && pp.script)  return pp.script + ' restart';
    if (action === 'status'  && pp.script)  return pp.script + ' status';
    // update: derive pip from script path
    if (action === 'update'  && pp.script) {
      // Extract the actual file path from "sudo -n /path/to/py.sh"
      const scriptPath = pp.script.replace(/^(sudo\s+-\w+\s+)+/, '').trim().split(' ')[0];
      const scriptDir = path.dirname(scriptPath);
      const pipPath = scriptDir + '/../env/bin/pip';
      return '([ -f ' + pipPath + ' ] && ' + pipPath + ' install --upgrade pyplanet 2>&1) || pip3 install --upgrade pyplanet --break-system-packages 2>&1';
    }
  }

  // Default fallback with {dir} substitution
  const defaults = CONTROLLER_DEFAULTS[type] || CONTROLLER_DEFAULTS.pyplanet;
  const cmd = defaults[action] || '';
  const dir = s.filesRoot || (s.mapsPath ? path.dirname(path.dirname(s.mapsPath)) : '') || '/home/tm01';
  return cmd.replace(/\{dir\}/g, dir);
}

function getControllerLinks(type) {
  return (CONTROLLER_DEFAULTS[type] || CONTROLLER_DEFAULTS.pyplanet).links || [];
}

function getBaseDir(s) {
  if (s && s.filesRoot) return s.filesRoot;
  if (s && s.mapsPath) return path.dirname(path.dirname(path.dirname(s.mapsPath)));
  if (s && s.matchPath) return path.dirname(path.dirname(s.matchPath));
  return '/home/tm01';
}

function sanitizeServiceNamePart(v) {
  return String(v || 'server').toLowerCase().replace(/[^a-z0-9_.-]+/g, '_').replace(/^_+|_+$/g, '') || 'server';
}

function getControllerRuntimeDir() {
  const dir = path.join(DATA_DIR || path.resolve('./data'), 'runtime', 'controllers');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function getServerActionLockPath(serverId, scope) {
  return path.join(getControllerRuntimeDir(), sanitizeServiceNamePart(scope) + '_' + sanitizeServiceNamePart(serverId) + '.lock');
}

async function withServerActionLock(serverId, scope, fn) {
  const lockPath = getServerActionLockPath(serverId, scope);
  const waitMs = 20000;
  const started = Date.now();
  while (true) {
    try {
      const fd = fs.openSync(lockPath, 'wx');
      fs.writeFileSync(fd, String(process.pid));
      try {
        return await fn();
      } finally {
        try { fs.closeSync(fd); } catch {}
        try { fs.unlinkSync(lockPath); } catch {}
      }
    } catch (err) {
      if (err && err.code !== 'EEXIST') throw err;
      try {
        const st = fs.statSync(lockPath);
        if ((Date.now() - st.mtimeMs) > 120000) {
          try { fs.unlinkSync(lockPath); } catch {}
          continue;
        }
      } catch {}
      if ((Date.now() - started) > waitMs) {
        throw Object.assign(new Error('Another action is already running for this server. Please wait a moment and try again.'), { status: 409 });
      }
      await new Promise(r => setTimeout(r, 250));
    }
  }
}

function shellEscapeSingle(value) {
  return "'" + String(value || '').replace(/'/g, "'\"'\"'") + "'";
}

function shellEscape(value) {
  return shellEscapeSingle(value);
}

function detectXasecoScript(server) {
  const baseDir = getBaseDir(server);
  const candidates = [
    path.join(baseDir, 'xaseco', 'aseco.php'),
    path.join(baseDir, 'xaseco', 'xaseco.php'),
  ];
  for (const file of candidates) {
    try { if (fs.existsSync(file) && fs.statSync(file).isFile()) return file; } catch {}
  }
  const fromStart = getControllerCmd(server, 'start');
  const m = String(fromStart || '').match(/(?:^|\s)(\/[^\s'\"]+\/(?:aseco|xaseco)\.php)(?=\s|$)/);
  if (m && fs.existsSync(m[1])) return m[1];
  return candidates[0];
}

function getXasecoPidFile(server) {
  return path.join(path.dirname(detectXasecoScript(server)), '.tm-panel-xaseco.pid');
}

function getXasecoLogPath(server) {
  return resolveLogPath(server, getControllerCmd(server, 'logfile')) || path.join(path.dirname(detectXasecoScript(server)), 'aseco.log');
}

function listMatchingXasecoPids(server) {
  const script = detectXasecoScript(server);
  const dir = path.dirname(script);
  const results = [];
  try {
    const raw = require('child_process').execSync('ps -eo pid=,args=', { encoding: 'utf8', shell: '/bin/bash' });
    raw.split('\n').forEach(line => {
      const trimmed = line.trim();
      if (!trimmed) return;
      const m = trimmed.match(/^(\d+)\s+(.*)$/);
      if (!m) return;
      const pid = Number(m[1]);
      const args = m[2] || '';
      if (!pid || pid === process.pid) return;
      if (!/php/i.test(args)) return;
      if (args.includes(script) || args.includes(dir + '/aseco.php') || args.includes(dir + '/xaseco.php')) {
        results.push({ pid, args });
      }
    });
  } catch {}
  return results;
}

function readAlivePid(pidFile) {
  try {
    const pid = Number(fs.readFileSync(pidFile, 'utf8').trim());
    if (pid) {
      process.kill(pid, 0);
      return pid;
    }
  } catch {}
  return null;
}

function writePidFile(pidFile, pid) {
  fs.mkdirSync(path.dirname(pidFile), { recursive: true });
  fs.writeFileSync(pidFile, String(pid));
}

async function handleXasecoAction(server, action) {
  const script = detectXasecoScript(server);
  const ctrlDir = path.dirname(script);
  const pidFile = getXasecoPidFile(server);
  const logPath = getXasecoLogPath(server);
  fs.mkdirSync(path.dirname(logPath), { recursive: true });

  const existingPid = readAlivePid(pidFile);
  const matching = listMatchingXasecoPids(server);

  if (action === 'status') {
    const pid = existingPid || (matching[0] && matching[0].pid) || null;
    if (pid && !existingPid) writePidFile(pidFile, pid);
    return {
      out: pid ? ('RUNNING\nPID=' + pid + '\nSCRIPT=' + script) : ('STOPPED\nSCRIPT=' + script),
      code: pid ? 0 : 1,
    };
  }

  if (action === 'stop') {
    const pids = [];
    if (existingPid) pids.push(existingPid);
    for (const hit of matching) if (!pids.includes(hit.pid)) pids.push(hit.pid);
    if (!pids.length) {
      try { fs.unlinkSync(pidFile); } catch {}
      return { out: 'Already stopped\nSCRIPT=' + script, code: 0 };
    }
    for (const pid of pids) {
      try { process.kill(pid, 'SIGTERM'); } catch {}
    }
    await new Promise(r => setTimeout(r, 1500));
    for (const pid of pids) {
      try { process.kill(pid, 0); process.kill(pid, 'SIGKILL'); } catch {}
    }
    try { fs.unlinkSync(pidFile); } catch {}
    return { out: 'Stopped XASECO\nPIDS=' + pids.join(', ') + '\nSCRIPT=' + script, code: 0 };
  }

  if (action === 'start') {
    const alreadyPid = existingPid || (matching[0] && matching[0].pid) || null;
    if (alreadyPid) {
      writePidFile(pidFile, alreadyPid);
      return { out: 'Already running\nPID=' + alreadyPid + '\nSCRIPT=' + script, code: 0 };
    }
    if (!fs.existsSync(script)) {
      return { out: 'XASECO script not found: ' + script, code: 1 };
    }
    const spawnCmd = 'cd ' + shellEscapeSingle(ctrlDir)
      + ' && nohup /usr/bin/php ' + shellEscapeSingle(script)
      + ' >> ' + shellEscapeSingle(logPath) + ' 2>&1 & echo $!';
    const startedPid = await new Promise(resolve => {
      exec(spawnCmd, { timeout: 15000, shell: '/bin/bash' }, (err, stdout) => {
        const pid = Number(String(stdout || '').trim().split(/\s+/).pop());
        resolve(pid || 0);
      });
    });
    await new Promise(r => setTimeout(r, 1200));
    const list = listMatchingXasecoPids(server);
        if (startedPid) {
      try { process.kill(startedPid, 0); writePidFile(pidFile, startedPid); return { out: 'Started XASECO\nPID=' + startedPid + '\nSCRIPT=' + script + '\nLOG=' + logPath, code: 0 }; } catch {}
    }
    if (list[0] && list[0].pid) {
      writePidFile(pidFile, list[0].pid);
      return { out: 'Started XASECO\nPID=' + list[0].pid + '\nSCRIPT=' + script + '\nLOG=' + logPath, code: 0 };
    }
    return { out: 'Start command finished, but process could not be confirmed.\nSCRIPT=' + script + '\nLOG=' + logPath, code: 1 };
  }

  if (action === 'restart') {
    const stopRes = await handleXasecoAction(server, 'stop');
    const startRes = await handleXasecoAction(server, 'start');
    return {
      out: ['[STOP]', stopRes.out, '', '[START]', startRes.out].join('\n'),
      code: startRes.code || stopRes.code,
    };
  }

  return { out: 'Unsupported XASECO action: ' + action, code: 1 };
}

// GET /:sid/controller/detect — auto-detect which controller is installed
router.get('/:sid/controller/detect', async (req, res) => {
  try {
    if (req.session.role !== 'admin') return res.status(403).json({error:'admin only'});
    const s = getServerForUser(req, req.params.sid);
    const dir = getBaseDir(s);
    const detected = [];

    // Check for each controller's signature files
    const checks = [
      { type: 'pyplanet',     file: path.join(dir, 'pyplanet', 'manage.py'),           label: 'PyPlanet' },
      { type: 'pyplanet',     file: path.join(dir, 'pyplanet', 'py.sh'),               label: 'PyPlanet' },
      { type: 'minicontrol',  file: path.join(dir, 'minicontrol', 'package.json'),     label: 'MINIcontrol' },
      { type: 'minicontrol',  file: path.join(dir, 'minicontrol', 'index.js'),         label: 'MINIcontrol' },
      { type: 'maniacontrol', file: path.join(dir, 'ManiaControl', 'ManiaControl.sh'), label: 'ManiaControl' },
      { type: 'maniacontrol', file: path.join(dir, 'ManiaControl', 'index.php'),       label: 'ManiaControl' },
      { type: 'nextcontrol',  file: path.join(dir, 'nextcontrol', 'package.json'),      label: 'NextControl' },
      { type: 'nextcontrol',  file: path.join(dir, 'nextcontrol', 'index.js'),          label: 'NextControl' },
      { type: 'evosc',        file: path.join(dir, 'evosc', 'composer.json'),           label: 'EvoSC' },
      { type: 'evosc',        file: path.join(dir, 'evosc', 'index.php'),               label: 'EvoSC' },
      { type: 'uaseco',       file: path.join(dir, 'uaseco', 'uaseco.sh'),             label: 'UASECO' },
      { type: 'uaseco',       file: path.join(dir, 'uaseco', 'aseco.php'),             label: 'UASECO' },
      { type: 'xaseco',       file: path.join(dir, 'xaseco', 'aseco.php'),             label: 'XASECO' },
      { type: 'xaseco',       file: path.join(dir, 'xaseco', 'xaseco.php'),            label: 'XASECO' },
    ];

    // Also check pyplanetCmds.script path
    const pp = s.pyplanetCmds || {};
    if (pp.script) {
      const sp = pp.script.replace(/^(sudo\s+-\w+\s+)+/, '').trim().split(' ')[0];
      if (fs.existsSync(sp)) {
        const scriptDir = path.dirname(sp);
        const parentDir = path.dirname(scriptDir);
        // Check what's in the parent dir
        if (fs.existsSync(path.join(parentDir, 'package.json'))) {
          detected.push({ type: 'minicontrol', label: 'MINIcontrol', path: parentDir, confidence: 'high', source: 'script' });
        } else if (fs.existsSync(path.join(parentDir, 'manage.py'))) {
          detected.push({ type: 'pyplanet', label: 'PyPlanet', path: parentDir, confidence: 'high', source: 'script' });
        } else if (fs.existsSync(path.join(scriptDir, 'package.json'))) {
          detected.push({ type: 'minicontrol', label: 'MINIcontrol', path: scriptDir, confidence: 'high', source: 'script' });
        } else if (fs.existsSync(sp)) {
          // Script exists but unsure what type - try reading it
          try {
            const content = fs.readFileSync(sp, 'utf8').slice(0, 500);
            if (content.includes('node') || content.includes('npm')) {
              detected.push({ type: 'minicontrol', label: 'MINIcontrol', path: scriptDir, confidence: 'medium', source: 'script' });
            } else if (content.includes('python') || content.includes('pyplanet')) {
              detected.push({ type: 'pyplanet', label: 'PyPlanet', path: scriptDir, confidence: 'medium', source: 'script' });
            } else if (content.includes('php') || content.includes('uaseco') || content.includes('aseco')) {
              detected.push({ type: 'uaseco', label: 'UASECO', path: scriptDir, confidence: 'medium', source: 'script' });
            }
          } catch {}
        }
      }
    }

    // File system checks
    const seen = new Set(detected.map(d => d.type));
    for (const c of checks) {
      if (!seen.has(c.type) && fs.existsSync(c.file)) {
        detected.push({ type: c.type, label: c.label, path: path.dirname(c.file), confidence: 'high', source: 'file' });
        seen.add(c.type);
      }
    }

    const best = detected[0] || null;
    res.json({ ok: true, detected, best });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// GET /:sid/controller — get controller info
router.get('/:sid/controller', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const safeType = sanitizeControllerTypeForServer(s, req, s.controllerType || 'pyplanet') || (isTmnfGame(s.game) ? 'xaseco' : 'pyplanet');
    const info = CONTROLLER_DEFAULTS[safeType] || {};
    const isAdmin = (req.session.role === 'admin');
    const controllerEnabled = isControllerEnabledForUser(s, req);
    const allowedTypes = getAllowedControllerTypes(s, req);
    const resolvedCmds = {};
    ['start','stop','restart','status','update','install','logfile'].forEach(a => {
      resolvedCmds[a] = isAdmin ? getControllerCmd(s, a) : '';
    });
    res.json({ ok: true, type: safeType, label: info.label || safeType, cmds: isAdmin ? (s.controllerCmds || {}) : {}, resolvedCmds, links: getControllerLinks(safeType), allowedTypes, isTmnf: isTmnfGame(s.game), controllerEnabled, canEditPaths: isAdmin, canSwitch: isAdmin && allowedTypes.length > 0, canInstall: isAdmin, canConfigure: isAdmin, canService: isAdmin });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// POST /:sid/controller/switch — change controller type
router.post('/:sid/controller/switch', async (req, res) => {
  try {
    if (req.session.role !== 'admin') return res.status(403).json({error:'admin only'});
    const s = getServerForUser(req, req.params.sid);
    const { type, install, configure, clearLeaderboardDb } = req.body || {};
    const nextType = sanitizeControllerTypeForServer(s, req, type);
    if (!nextType) return res.status(400).json({error:'No controller is enabled for this server'});
    const updated = { ...s, controllerType: nextType };
    db.servers.update(s.id, updated);
    const refreshed = db.servers.findById(s.id) || updated;
    const notes = [];
    if (clearLeaderboardDb) {
      try { notes.push('Leaderboard DB cleared: ' + (await clearLeaderboardTables(refreshed)).join(', ')); }
      catch (e) { notes.push('Leaderboard DB clear failed: ' + e.message); }
    }
    if (install) {
      try {
        const cmd = getControllerCmd(refreshed, 'install');
        notes.push(cmd ? String(await runCmd(cmd, 300000, process.env) || 'Install complete').trim() : 'No install command configured');
      } catch (e) { notes.push('Install failed: ' + e.message); }
    }
    if (configure) {
      try { notes.push(String(autoConfigureController(refreshed))); }
      catch (e) { notes.push('Configure failed: ' + e.message); }
    }
    res.json({ ok: true, type: nextType, notes });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// POST /:sid/controller/:action — start/stop/restart/status/update/install
router.post('/:sid/controller/:action', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    const action = req.params.action;
    if (!isControllerEnabledForUser(s, req)) return res.status(403).json({error:'Controller is disabled for this game. Ask admin to enable it.'});
    const validActions = ['start','stop','restart','status','update','install'];
    if (!validActions.includes(action)) return res.status(400).json({error:'Invalid action'});
    if (['update','install'].includes(action) && req.session.role !== 'admin')
      return res.status(403).json({error:'admin only'});

    const output = await withServerActionLock(s.id, 'controller', async () => {
      if ((s.controllerType || 'pyplanet') === 'xaseco' && ['start','stop','restart','status'].includes(action)) {
        return handleXasecoAction(s, action);
      }
      const cmd = getControllerCmd(s, action);
      if (!cmd) return { out: 'No command configured for ' + action, code: 1 };
      return await new Promise((resolve) => {
        exec(cmd, { timeout: 180000, maxBuffer: 4*1024*1024, shell: '/bin/bash' }, (err, stdout, stderr) => {
          const combined = [stdout, stderr].filter(Boolean).join('\n').trim();
          resolve({ out: combined || (err ? err.message : '(no output)'), code: err ? (err.code||1) : 0 });
        });
      });
    });

    let out = output.out;
    if (action === 'install') {
      try { out += '\n\n' + autoConfigureController(s); } catch(e) { out += '\n\nCONFIG: ' + e.message; }
    }
    res.json({ ok: true, action, output: out, code: output.code });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// POST /:sid/controller/service — generate + install systemd service for persistent running
router.post('/:sid/controller/service', async (req, res) => {
  try {
    if (req.session.role !== 'admin') return res.status(403).json({error:'admin only'});
    const s = getServerForUser(req, req.params.sid);
    const type = s.controllerType || 'minicontrol';
    const dir = getBaseDir(s);
    const ctrlDir = path.join(dir, type === 'maniacontrol' ? 'ManiaControl' : type);
    const label = s.label.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    const serviceName = 'tm_' + label + '_ctrl';

    let execStart, workDir, user;
    // Detect system user from dir
    user = dir.split('/')[2] || 'root'; // /home/tm01 → tm01

    if (type === 'xaseco') {
    var xDir = path.join(dir, 'xaseco');
    var cfgPath = path.join(xDir, 'config', 'xaseco.xml');
    if (!fs.existsSync(xDir)) return 'XASECO not found at ' + xDir;
    fs.mkdirSync(path.join(xDir, 'config'), {recursive:true});
    var xml = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
      + '<!-- Auto-generated by TM Panel -->\n'
      + '<aseco>\n'
      + '  <masterserver_account>\n'
      + '    <login>YOUR_MASTERSERVER_LOGIN</login>\n'
      + '    <password>YOUR_MASTERSERVER_PASSWORD</password>\n'
      + '    <nation>OTH</nation>\n'
      + '  </masterserver_account>\n'
      + '  <dedicated_server>\n'
      + '    <ip>' + host + '</ip>\n'
      + '    <port>' + port + '</port>\n'
      + '    <login>' + rpcUser + '</login>\n'
      + '    <password>' + rpcPass + '</password>\n'
      + '  </dedicated_server>\n'
      + '  <mysql>\n'
      + '    <host>localhost</host>\n'
      + '    <username>xaseco</username>\n'
      + '    <password>CHANGE_ME</password>\n'
      + '    <database>xaseco_' + sid + '</database>\n'
      + '  </mysql>\n'
      + '  <masteradmin_list>\n'
      + '    <masteradmin>YOUR_MANIAPLANET_LOGIN</masteradmin>\n'
      + '  </masteradmin_list>\n'
      + '</aseco>';
    if (!fs.existsSync(cfgPath)) {
      fs.writeFileSync(cfgPath, xml);
      return '✅ config/xaseco.xml written.\n→ Set masterserver login/password\n→ Edit MySQL password\n→ Set masteradmin\nServer: ' + host + ':' + port;
    }
    return 'ℹ️ config/xaseco.xml already exists.\nServer: ' + host + ':' + port;
  }

  if (type === 'minicontrol') {
      execStart = '/usr/bin/node ' + path.join(ctrlDir, 'index.js');
      workDir = ctrlDir;
    } else if (type === 'nextcontrol') {
      execStart = '/usr/bin/node ' + path.join(ctrlDir, 'index.js');
      workDir = ctrlDir;
    } else if (type === 'pyplanet') {
      const pp = s.pyplanetCmds || {};
      const script = pp.script ? pp.script.replace(/^(sudo\s+-\w+\s+)+/, '').trim().split(' ')[0] : path.join(ctrlDir, 'py.sh');
      execStart = script + ' start_fg'; // pyplanet foreground mode
      workDir = path.dirname(script);
    } else if (type === 'uaseco') {
      execStart = '/usr/bin/php ' + path.join(ctrlDir, 'aseco.php') + ' tmf';
      workDir = ctrlDir;
    } else if (type === 'maniacontrol') {
      execStart = '/usr/bin/php ' + path.join(ctrlDir, 'ManiaControl.php');
      workDir = ctrlDir;
    } else if (type === 'evosc') {
      execStart = '/usr/bin/php ' + path.join(ctrlDir, 'index.php');
      workDir = ctrlDir;
    } else {
      execStart = path.join(ctrlDir, 'start.sh');
      workDir = ctrlDir;
    }

    const serviceContent = [
      '[Unit]',
      'Description=TrackMania Controller - ' + s.label,
      'After=network.target',
      'Wants=network-online.target',
      '',
      '[Service]',
      'Type=simple',
      'User=' + user,
      'WorkingDirectory=' + workDir,
      'ExecStart=' + execStart,
      'Restart=always',
      'RestartSec=5',
      'StartLimitIntervalSec=60',
      'StartLimitBurst=5',
      'StandardOutput=append:' + path.join(ctrlDir, 'logs', 'service.log'),
      'StandardError=append:' + path.join(ctrlDir, 'logs', 'service.log'),
      '',
      '[Install]',
      'WantedBy=multi-user.target',
    ].join('\n');

    const servicePath = '/etc/systemd/system/' + serviceName + '.service';

    // Write service file and enable it
    const { exec } = require('child_process');
    fs.mkdirSync(path.join(ctrlDir, 'logs'), {recursive: true});
    fs.writeFileSync(servicePath, serviceContent);

    const cmds = [
      'systemctl daemon-reload',
      'systemctl enable ' + serviceName,
      'systemctl restart ' + serviceName,
      'systemctl status ' + serviceName + ' --no-pager -l',
    ].join(' && ');

    const output = await new Promise(resolve => {
      exec(cmds, {timeout:30000, shell:'/bin/bash'}, (err,out,err2) => {
        resolve([out,err2].filter(Boolean).join('\n').trim() || (err&&err.message) || 'Done');
      });
    });

    res.json({ ok: true, serviceName, servicePath, output });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// POST /:sid/controller/configure — write config files from DB
router.post('/:sid/controller/configure', async (req, res) => {
  try {
    if (req.session.role !== 'admin') return res.status(403).json({error:'admin only'});
    const s = getServerForUser(req, req.params.sid);
    const result = autoConfigureController(s);
    res.json({ ok: true, output: result });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// GET /:sid/controller/logs — read controller logfile
router.get('/:sid/controller/logs', async (req, res) => {
  try {
    const s = getServerForUser(req, req.params.sid);
    res.set({'Cache-Control':'no-store,no-cache'});
    const logPath = resolveLogPath(s, getControllerCmd(s, 'logfile'));
    if (!logPath) return res.status(400).json({error:'log not found', tried: getControllerCmd(s,'logfile')||'(not set)'});
    const lines = fs.readFileSync(logPath, 'utf8').split('\n').slice(-500).join('\n');
    res.json({ ok: true, log: lines, path: logPath });
  } catch(err) { res.status(err.status||500).json({error:err.message}); }
});

// Auto-configure controller with server credentials
function autoConfigureController(s) {
  var type = s.controllerType || 'pyplanet';
  // Derive base dir same way as getControllerCmd
  var dir = s.filesRoot;
  if (!dir && s.pyplanetCmds && s.pyplanetCmds.script) {
    var sp2 = s.pyplanetCmds.script.replace(/^(sudo\s+-\w+\s+)+/, '').trim().split(' ')[0];
    dir = path.dirname(path.dirname(sp2));
  }
  if (!dir && s.mapsPath) dir = path.dirname(path.dirname(path.dirname(s.mapsPath)));
  if (!dir) dir = '/home/tm01';
  var host = s.host || '127.0.0.1';
  var port = s.port || 5000;
  var rpcUser = s.rpcUser || 'SuperAdmin';
  var rpcPass = s.rpcPass || '';
  var label = s.label || 'TM Server';
  var sid = s.id || 1;

  if (type === 'pyplanet') {
    var settingsDir = path.join(dir, 'pyplanet');
    var settingsPath = path.join(settingsDir, 'settings', 'base.py');
    if (!fs.existsSync(settingsDir)) return 'PyPlanet not yet installed at ' + settingsDir;
    var content = '# Auto-generated by TM Panel\n'
      + '# Edit MySQL credentials and OWNER before starting!\n\n'
      + 'DATABASES = {\n'
      + '    "default": {\n'
      + '        "ENGINE": "peewee_async.MySQLDatabase",\n'
      + '        "NAME": "pyplanet",\n'
      + '        "OPTIONS": {"host": "localhost", "user": "pyplanet", "password": "CHANGE_ME", "charset": "utf8mb4"},\n'
      + '    }\n'
      + '}\n\n'
      + 'SERVERS = [\n'
      + '    {"name": "' + label + '", "dedicated_host": "' + host + '", "dedicated_port": ' + port + ', "dedicated_pass": "' + rpcPass + '"}\n'
      + ']\n\n'
      + 'OWNER = "YOUR_MANIAPLANET_LOGIN"\n';
    fs.mkdirSync(path.join(settingsDir, 'settings'), {recursive:true});
    if (!fs.existsSync(settingsPath)) {
      fs.writeFileSync(settingsPath, content);
      return '✅ settings/base.py written with your server data.\n→ Edit MySQL password\n→ Set OWNER to your login\nServer: ' + host + ':' + port;
    }
    return 'ℹ️ settings/base.py already exists (not overwritten).\nServer data: ' + host + ':' + port + ' | user: ' + rpcUser;
  }

  if (type === 'uaseco') {
    var uasecoDir = path.join(dir, 'uaseco');
    var cfgPath = path.join(uasecoDir, 'config', 'uaseco.xml');
    if (!fs.existsSync(uasecoDir)) return 'UASECO not found at ' + uasecoDir;
    fs.mkdirSync(path.join(uasecoDir, 'config'), {recursive:true});
    var xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
      + '<!-- Auto-generated by TM Panel -->\n'
      + '<uaseco>\n'
      + '  <server>\n'
      + '    <ip>' + host + '</ip>\n'
      + '    <port>' + port + '</port>\n'
      + '    <login>' + rpcUser + '</login>\n'
      + '    <password>' + rpcPass + '</password>\n'
      + '    <nation>OTH</nation>\n'
      + '  </server>\n'
      + '  <database>\n'
      + '    <type>MySQL</type>\n'
      + '    <host>localhost</host>\n'
      + '    <login>uaseco</login>\n'
      + '    <password>CHANGE_ME</password>\n'
      + '    <database>uaseco_' + sid + '</database>\n'
      + '  </database>\n'
      + '  <masteradmin>\n'
      + '    <tmlogin>YOUR_MANIAPLANET_LOGIN</tmlogin>\n'
      + '  </masteradmin>\n'
      + '</uaseco>';
    if (!fs.existsSync(cfgPath)) {
      fs.writeFileSync(cfgPath, xml);
      return '✅ config/uaseco.xml written with your server data.\n→ Edit MySQL password\n→ Set masteradmin login\nServer: ' + host + ':' + port;
    }
    return 'ℹ️ config/uaseco.xml already exists (not overwritten).\nServer: ' + host + ':' + port;
  }

  if (type === 'maniacontrol') {
    var mcDir = path.join(dir, 'ManiaControl');
    if (!fs.existsSync(mcDir)) return 'ManiaControl not found at ' + mcDir;
    fs.mkdirSync(path.join(mcDir, 'configs'), {recursive:true});
    fs.mkdirSync(path.join(mcDir, 'logs'), {recursive:true});
    var msgs = [];
    // Write server.xml
    var cfgPath = path.join(mcDir, 'configs', 'server.xml');
    if (!fs.existsSync(cfgPath)) {
      var xml = '<?xml version="1.0" encoding="UTF-8"?>\n<!-- Auto-generated by TM Panel -->\n<maniacontrol>\n'
        + '  <server>\n    <host>' + host + '</host>\n    <port>' + port + '</port>\n    <login>' + rpcUser + '</login>\n    <pass>' + rpcPass + '</pass>\n  </server>\n'
        + '  <database>\n    <type>mysql</type>\n    <host>localhost</host>\n    <port>3306</port>\n    <login>maniacontrol</login>\n    <pass>CHANGE_ME</pass>\n    <db_name>maniacontrol_' + sid + '</db_name>\n  </database>\n'
        + '  <masteradmins>\n    <masteradmin>YOUR_MANIAPLANET_LOGIN</masteradmin>\n  </masteradmins>\n</maniacontrol>';
      fs.writeFileSync(cfgPath, xml);
      msgs.push('✅ configs/server.xml written → Edit MySQL password, set masteradmin');
    } else { msgs.push('ℹ️ configs/server.xml already exists'); }
    // Create ManiaControl.sh wrapper
    var shPath = path.join(mcDir, 'ManiaControl.sh');
    if (!fs.existsSync(shPath)) {
      var sh = '#!/bin/bash\n# ManiaControl wrapper — auto-generated by TM Panel\n'
        + 'DIR="$(cd "$(dirname "$0")" && pwd)"\n'
        + 'PIDFILE="$DIR/maniacontrol.pid"\n'
        + 'LOG="$DIR/logs/ManiaControl.log"\n'
        + 'mkdir -p "$DIR/logs"\n\n'
        + 'case "$1" in\n'
        + '  start)\n    if [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null; then\n      echo "Already running"; else\n      cd "$DIR" && php ManiaControl.php >> "$LOG" 2>&1 &\n      echo $! > "$PIDFILE"; echo "Started (PID $!)"; fi;;\n'
        + '  stop)\n    if [ -f "$PIDFILE" ]; then kill "$(cat $PIDFILE)" 2>/dev/null && echo "Stopped" || echo "Not running"; rm -f "$PIDFILE"; else echo "Not running"; fi;;\n'
        + '  restart) "$0" stop; sleep 1; "$0" start;;\n'
        + '  status)\n    [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null && echo "Running (PID $(cat $PIDFILE))" || echo "Stopped";;\n'
        + '  *) echo "Usage: $0 {start|stop|restart|status}"; exit 1;;\nesac\n';
      fs.writeFileSync(shPath, sh);
      require('child_process').execSync('chmod +x ' + shPath);
      msgs.push('✅ ManiaControl.sh wrapper created');
    }
    msgs.push('Server: ' + host + ':' + port);
    return msgs.join('\n');
  }

  if (type === 'minicontrol') {
    var mcDir = path.join(dir, 'minicontrol');
    var envPath = path.join(mcDir, '.env');
    if (!fs.existsSync(mcDir)) return 'MINIcontrol not found at ' + mcDir;
    var env = '# Auto-generated by TM Panel\n'
      + 'SERVER_HOST=' + host + '\n'
      + 'SERVER_PORT=' + port + '\n'
      + 'SERVER_PASS=' + rpcPass + '\n'
      + 'SUPERADMIN_PASS=' + rpcPass + '\n'
      + 'DB_HOST=localhost\nDB_PORT=3306\n'
      + 'DB_USER=minicontrol\nDB_PASS=CHANGE_ME\n'
      + 'DB_NAME=minicontrol_' + sid + '\n'
      + 'ADMIN_LOGIN=YOUR_MANIAPLANET_LOGIN\n';
    var msgs = [];
    if (!fs.existsSync(envPath)) {
      fs.writeFileSync(envPath, env);
      msgs.push('✅ .env written → Edit DB_PASS, set ADMIN_LOGIN');
    } else {
      msgs.push('ℹ️ .env already exists');
    }
    // Create wrapper sh script for easy start/stop
    var shPath = path.join(mcDir, 'minicontrol.sh');
    if (!fs.existsSync(shPath)) {
      var sh = '#!/bin/bash\n'
        + '# MINIcontrol wrapper — auto-generated by TM Panel\n'
        + 'DIR="$(cd "$(dirname "$0")" && pwd)"\n'
        + 'PIDFILE="$DIR/minicontrol.pid"\n'
        + 'LOG="$DIR/logs/minicontrol.log"\n'
        + 'mkdir -p "$DIR/logs"\n\n'
        + 'case "$1" in\n'
        + '  start)\n'
        + '    if [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null; then\n'
        + '      echo "Already running (PID $(cat $PIDFILE))"\n'
        + '    else\n'
        + '      cd "$DIR" && node index.js >> "$LOG" 2>&1 &\n'
        + '      echo $! > "$PIDFILE"\n'
        + '      echo "Started MINIcontrol (PID $!)"\n'
        + '    fi;;\n'
        + '  stop)\n'
        + '    if [ -f "$PIDFILE" ]; then\n'
        + '      kill "$(cat $PIDFILE)" 2>/dev/null && echo "Stopped" || echo "Not running"\n'
        + '      rm -f "$PIDFILE"\n'
        + '    else echo "Not running"; fi;;\n'
        + '  restart) "$0" stop; sleep 1; "$0" start;;\n'
        + '  status)\n'
        + '    if [ -f "$PIDFILE" ] && kill -0 "$(cat $PIDFILE)" 2>/dev/null; then\n'
        + '      echo "Running (PID $(cat $PIDFILE))"\n'
        + '    else echo "Stopped"; fi;;\n'
        + '  *) echo "Usage: $0 {start|stop|restart|status}"; exit 1;;\n'
        + 'esac\n';
      fs.writeFileSync(shPath, sh);
      require('child_process').execSync('chmod +x ' + shPath);
      msgs.push('✅ minicontrol.sh wrapper created');
    }
    msgs.push('Server: ' + host + ':' + port);
    return msgs.join('\n');
  }

  return 'No auto-config available for ' + type;
}

// ── Support tickets (any logged-in user) ─────────────────────────────────────
router.get('/support/tickets', (req, res) => {
  try {
    const userId = req.session.userId, role = req.session.role;
    const t = role === 'admin' ? db.tickets.findAll() : db.tickets.findByUser(userId);
    res.json(t);
  } catch(err) { res.status(500).json({error:err.message}); }
});

router.post('/support/tickets', (req, res) => {
  try {
    const { subject, message, serverId } = req.body;
    if (!subject || !message) return res.status(400).json({error:'subject and message required'});
    const id = db.tickets.create(req.session.userId, serverId||null, subject, message);
    res.json({ok:true, id});
  } catch(err) { res.status(500).json({error:err.message}); }
});

router.post('/support/tickets/:id/reply', (req, res) => {
  try {
    const { reply, status } = req.body;
    if (req.session.role !== 'admin') return res.status(403).json({error:'admin only'});
    db.tickets.reply(Number(req.params.id), reply||'', status||'answered');
    res.json({ok:true});
  } catch(err) { res.status(500).json({error:err.message}); }
});

router.patch('/support/tickets/:id/status', (req, res) => {
  try {
    if (req.session.role !== 'admin') return res.status(403).json({error:'admin only'});
    db.tickets.updateStatus(Number(req.params.id), req.body.status||'closed');
    res.json({ok:true});
  } catch(err) { res.status(500).json({error:err.message}); }
});

router.delete('/support/tickets/:id', (req, res) => {
  try {
    const ticket = db.tickets.findById(Number(req.params.id));
    if (!ticket) return res.status(404).json({error:'not found'});
    if (req.session.role !== 'admin' && ticket.user_id !== req.session.userId)
      return res.status(403).json({error:'forbidden'});
    db.tickets.delete(Number(req.params.id));
    res.json({ok:true});
  } catch(err) { res.status(500).json({error:err.message}); }
});

// ── User credentials view (per their assigned servers) ───────────────────────
router.get('/user/credentials', (req, res) => {
  try {
    const userId = req.session.userId, role = req.session.role;
    const servers = db.servers.findAll();
    const serverMap = {};
    servers.forEach(function(s){ serverMap[Number(s.id)] = s.label || ('Server #' + s.id); });
    let creds = [];
    if (role === 'admin') {
      creds = db.credentials.findAll();
    } else {
      const serverIds = db.users.getServers(userId).map(Number);
      const globalCreds = db.credentials.findGlobal();
      const serverCreds = serverIds.flatMap(function(sid){ return db.credentials.findByServer(sid); });
      const seen = new Set();
      creds = globalCreds.concat(serverCreds).filter(function(c){
        if (seen.has(c.id)) return false;
        seen.add(c.id);
        return true;
      });
    }
    creds = creds.map(function(c){
      return {
        ...c,
        serverLabel: Number(c.serverId) > 0 ? (serverMap[Number(c.serverId)] || ('Server #' + c.serverId)) : 'Global'
      };
    });
    res.json(creds);
  } catch(err) { res.status(500).json({error:err.message}); }
});


function lbSafeTable(name, fallback) {
  const v = String(name || fallback || '').trim();
  if (!/^[A-Za-z0-9_]+$/.test(v)) throw new Error('invalid leaderboard table name');
  return '`' + v + '`';
}
function lbCfgFromServer(server) {
  const bc = server.backupConfig || {};
  const lb = bc.leaderboardDb || {};
  const cfg = {
    host: String(lb.host || bc.mysqlHost || '').trim(),
    port: parseInt(lb.port || bc.mysqlPort || 3306, 10) || 3306,
    user: String(lb.user || bc.mysqlUser || '').trim(),
    password: String(lb.password || bc.mysqlPass || ''),
    database: String(lb.database || bc.mysqlDb || '').trim(),
    playersTable: String(lb.playersTable || 'players').trim(),
    recordsTable: String(lb.recordsTable || 'records').trim(),
    mapsTable: String(lb.mapsTable || 'challenges').trim(),
    rankTable: String(lb.rankTable || 'rs_rank').trim(),
    historyTable: String(lb.historyTable || 'rs_times').trim(),
    playersExtraTable: String(lb.playersExtraTable || 'players_extra').trim(),
    enabled: lb.enabled !== false
  };
  return cfg;
}
async function lbOpen(server) {
  if (!mysql) throw new Error('mysql2 not installed. Run npm install');
  const cfg = lbCfgFromServer(server);
  if (!cfg.enabled) throw new Error('Leaderboard DB disabled for this server');
  if (!cfg.host || !cfg.user || !cfg.database) throw new Error('Leaderboard database is not configured for this server');
  const conn = await mysql.createConnection({
    host: cfg.host,
    port: cfg.port,
    user: cfg.user,
    password: cfg.password,
    database: cfg.database,
    charset: 'utf8mb4',
    connectTimeout: 7000
  });
  return { conn, cfg };
}

async function clearLeaderboardTables(server) {
  let conn;
  try {
    const opened = await lbOpen(server);
    conn = opened.conn;
    const cfg = opened.cfg;
    const tables = [cfg.recordsTable, cfg.historyTable, cfg.rankTable, cfg.playersTable, cfg.playersExtraTable, cfg.mapsTable]
      .map(v => lbSafeTable(v, ''))
      .filter(Boolean);
    const unique = Array.from(new Set(tables));
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    for (const tbl of unique) {
      try { await conn.query('TRUNCATE TABLE ' + tbl); }
      catch (e) { try { await conn.query('DELETE FROM ' + tbl); } catch (_) {} }
    }
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');
    return unique;
  } finally {
    try { if (conn) await conn.end(); } catch {}
  }
}

function lbMs(v) { return Number(v || 0); }

        function lbLimit(raw, defVal, maxVal) {
          const v = String(raw == null ? defVal : raw).trim().toLowerCase();
          if (v === 'all') return maxVal;
          const n = parseInt(v || String(defVal), 10) || defVal;
          return Math.min(Math.max(n, 1), maxVal);
        }
        function lbDateExpr(tableAlias, col, kind) {
          return kind === 'unix' ? `FROM_UNIXTIME(${tableAlias}.${col})` : `${tableAlias}.${col}`;
        }
        function lbWrPlayerSub(recordsT) {
          return `(SELECT r.PlayerId as PlayerId, COUNT(*) as recordCount, MIN(r.Score) as bestWrScore, MAX(r.Date) as latestWr
`
               + ` FROM ${recordsT} r
`
               + ` INNER JOIN (SELECT ChallengeId, MIN(Score) as bestScore FROM ${recordsT} GROUP BY ChallengeId) w
`
               + `   ON w.ChallengeId = r.ChallengeId AND w.bestScore = r.Score
`
               + ` GROUP BY r.PlayerId)`;
        }
        function lbWrMapSub(recordsT) {
          return `(SELECT r.ChallengeId as ChallengeId, COUNT(*) as recordCount, MIN(r.Score) as bestScore, MAX(r.Date) as latestRecord
`
               + ` FROM ${recordsT} r
`
               + ` INNER JOIN (SELECT ChallengeId, MIN(Score) as bestScore FROM ${recordsT} GROUP BY ChallengeId) w
`
               + `   ON w.ChallengeId = r.ChallengeId AND w.bestScore = r.Score
`
               + ` GROUP BY r.ChallengeId)`;
        }
        function lbHistoryPlayerSub(historyT) {
          return `(SELECT t.playerID as PlayerId, COUNT(*) as finishedCount, COUNT(DISTINCT t.challengeID) as finishedMaps, COUNT(DISTINCT t.challengeID) as mapCount, MIN(t.score) as bestScore, MAX(t.date) as latestRecordTs
`
               + ` FROM ${historyT} t
`
               + ` GROUP BY t.playerID)`;
        }
        function lbHistoryMapSub(historyT) {
          return `(SELECT t.challengeID as ChallengeId, COUNT(DISTINCT t.playerID) as driverCount, COUNT(*) as finishedCount, MIN(t.score) as bestScore, MAX(t.date) as latestRecordTs
`
               + ` FROM ${historyT} t
`
               + ` GROUP BY t.challengeID)`;
        }

router.get('/:sid/leaderboard/overview', async (req, res) => {
  let conn;
  try {
    const server = getServerForUser(req, req.params.sid);
    const opened = await lbOpen(server); conn = opened.conn; const cfg = opened.cfg;
    const playersT = lbSafeTable(cfg.playersTable, 'players');
    const recordsT = lbSafeTable(cfg.recordsTable, 'records');
    const mapsT = lbSafeTable(cfg.mapsTable, 'challenges');
    const historyT = lbSafeTable(cfg.historyTable, 'rs_times');
    const rankT = lbSafeTable(cfg.rankTable, 'rs_rank');
const extraT = lbSafeTable(cfg.playersExtraTable, 'players_extra');
const wrPlayerSub = lbWrPlayerSub(recordsT);
const wrMapSub = lbWrMapSub(recordsT);
const histPlayerSub = lbHistoryPlayerSub(historyT);
const histMapSub = lbHistoryMapSub(historyT);
const [countRows] = await conn.query(`SELECT
  (SELECT COUNT(*) FROM ${playersT}) players,
  (SELECT COUNT(*) FROM ${wrPlayerSub} x) records,
  (SELECT COUNT(*) FROM ${mapsT}) maps`);
const [latestRows] = await conn.query(`SELECT t.ID as id, t.score as score, FROM_UNIXTIME(t.date) as date, p.Id as playerId, p.Login as login, p.NickName as nickname FROM ${historyT} t INNER JOIN ${playersT} p ON p.Id=t.playerID WHERE t.challengeID=? ORDER BY t.date DESC LIMIT 50`, [cid]);
    res.json({ ok:true, map: metaRows[0], records: topRows, latest: latestRows, source: cfg });
  } catch (err) { res.status(500).json({ error: err.message }); }
  finally { try { if (conn) await conn.end(); } catch {} }
});
router.get('/:sid/leaderboard/latest', async (req, res) => {
  let conn;
  try {
    const server = getServerForUser(req, req.params.sid);
    const opened = await lbOpen(server); conn = opened.conn; const cfg = opened.cfg;
    const mapsT = lbSafeTable(cfg.mapsTable, 'challenges');
    const recordsT = lbSafeTable(cfg.recordsTable, 'records');
    const playersT = lbSafeTable(cfg.playersTable, 'players');
    const limit = lbLimit(req.query.limit, 50, 5000);
    const q = String(req.query.q || '').trim();
    const where = q ? `WHERE p.Login LIKE ? OR p.NickName LIKE ? OR c.Name LIKE ? OR c.Author LIKE ? OR c.Uid LIKE ?` : '';
    const params = q ? [`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`] : [];
    const [rows] = await conn.query(`SELECT r.Id as id, r.Score as score, r.Date as date, r.Checkpoints as checkpoints, p.Id as playerId, p.Login as login, p.NickName as nickname, p.Nation as nation, c.Id as challengeId, c.Uid as uid, c.Name as mapName, c.Author as author, c.Environment as environment FROM ${recordsT} r INNER JOIN ${playersT} p ON p.Id=r.PlayerId INNER JOIN ${mapsT} c ON c.Id=r.ChallengeId ${where} ORDER BY r.Date DESC LIMIT ${limit}`, params);
    res.json({ ok:true, items: rows, source: cfg });
  } catch (err) { res.status(500).json({ error: err.message }); }
  finally { try { if (conn) await conn.end(); } catch {} }
});


function lbNormalizeSlug(v) {
  return String(v || '').trim().toLowerCase();
}
function lbValidateSlug(v) {
  const slug = lbNormalizeSlug(v);
  if (!/^[a-z0-9][a-z0-9_-]{1,47}$/.test(slug)) {
    throw Object.assign(new Error('Slug must be 2-48 chars and use only a-z, 0-9, - and _'), { status: 400 });
  }
  return slug;
}
router.get('/:sid/leaderboard/share', (req, res) => {
  try {
    getServerForUser(req, req.params.sid);
    const share = db.leaderboardShares.findByServer(Number(req.params.sid));
    res.json({ ok: true, share, url: share ? ('/lb/' + share.slug) : null });
  } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});
router.post('/:sid/leaderboard/share', (req, res) => {
  try {
    const server = getServerForUser(req, req.params.sid);
    const slug = lbValidateSlug(req.body && req.body.slug);
    if (db.leaderboardShares.slugExists(slug, Number(server.id))) {
      return res.status(409).json({ error: 'Slug already exists' });
    }
    const existing = db.leaderboardShares.findByServer(Number(server.id));
    const share = db.leaderboardShares.upsert(Number(server.id), slug, existing ? existing.enabled : true);
    res.json({ ok: true, share, url: '/lb/' + share.slug });
  } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});
router.put('/:sid/leaderboard/share/toggle', (req, res) => {
  try {
    getServerForUser(req, req.params.sid);
    const existing = db.leaderboardShares.findByServer(Number(req.params.sid));
    if (!existing) return res.status(404).json({ error: 'No share exists for this server yet' });
    const share = db.leaderboardShares.setEnabled(Number(req.params.sid), req.body && req.body.enabled !== false);
    res.json({ ok: true, share, url: '/lb/' + share.slug });
  } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});
router.delete('/:sid/leaderboard/share', (req, res) => {
  try {
    getServerForUser(req, req.params.sid);
    db.leaderboardShares.delete(Number(req.params.sid));
    res.json({ ok: true });
  } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});

router.get('/faq', (req, res) => {
  try {
    res.json(db.faq.findAll(false));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
