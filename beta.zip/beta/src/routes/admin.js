const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../lib/db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAdmin);

function parseJsonish(value, fallback = {}) {
  if (!value) return fallback;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return fallback; }
}

function parseServerData(d) {
  return {
    label: (d.label || '').trim() || 'New Server',
    game: 'TrackMania',
    host: (d.host || '127.0.0.1').trim(),
    port: Number(d.port) || 5000,
    rpcUser: (d.rpcUser || 'SuperAdmin').trim(),
    rpcPass: (d.rpcPass || '').trim(),
    mapsPath: (d.mapsPath || '').trim(),
    matchPath: (d.matchPath || '').trim(),
    filesRoot: (d.filesRoot || '').trim(),
    dedicatedCmds: parseJsonish(d.dedicatedCmds || d.dedicated_cmds || {}, {}),
    pyplanetCmds: {},
    controllerType: (d.controllerType || 'none').trim(),
    controllerCmds: parseJsonish(d.controllerCmds || d.controller_cmds || {}, {}),
    backupConfig: parseJsonish(d.backupConfig || d.backup_config || {}, {}),
    controllerEnabled: !!(d.controllerEnabled || d.controller_enabled),
    nodeId: null,
  };
}

router.get('/servers', (_req, res) => {
  try {
    res.json(db.servers.findAll().map((s) => ({ ...s, rpcPass: '***' })));
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.get('/servers/:id', (req, res) => {
  try {
    const server = db.servers.findById(Number(req.params.id));
    if (!server) return res.status(404).json({ error: 'not found' });
    res.json(server);
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.post('/servers', (req, res) => {
  try {
    const data = parseServerData(req.body || {});
    const body = req.body || {};
    let id;
    if (body.id) {
      id = Number(body.id);
      db.servers.update(id, data);
    } else {
      id = db.servers.create(data);
      for (const user of db.users.findAll()) {
        if (user.role === 'admin') {
          const current = db.users.getServers(user.id);
          if (!current.includes(id)) db.users.setServers(user.id, current.concat([id]));
        }
      }
    }
    res.json({ ok: true, id });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.delete('/servers/:id', (req, res) => {
  try {
    db.servers.delete(Number(req.params.id));
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.get('/users', (_req, res) => {
  try {
    const list = db.users.findAll().map((u) => ({
      id: u.id,
      username: u.username,
      role: u.role,
      createdAt: u.created_at,
      servers: u.servers || []
    }));
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.post('/users', async (req, res) => {
  try {
    const d = req.body || {};
    const userId = d.id ? Number(d.id) : null;
    const username = String(d.username || '').trim();
    const role = String(d.role || 'user').trim() === 'admin' ? 'admin' : 'user';
    const password = String(d.password || '');
    const serverIds = Array.isArray(d.servers) ? d.servers.map(Number) : [];
    if (!username) return res.status(400).json({ error: 'username required' });

    const allSids = db.servers.getAllIds();
    const resolvedSids = role === 'admin' ? allSids : serverIds.filter((id) => allSids.includes(id));

    if (userId) {
      const current = db.users.findById(userId);
      if (!current) return res.status(404).json({ error: 'user not found' });
      const existingByName = db.users.findByUsername(username);
      if (existingByName && Number(existingByName.id) !== userId) return res.status(400).json({ error: 'username already exists' });
      const update = { username, role };
      if (password) update.password_hash = await bcrypt.hash(password, 12);
      db.users.update(userId, update);
      db.users.setServers(userId, resolvedSids);
      if (req.session.userId === userId) {
        req.session.username = username;
        req.session.role = role;
      }
    } else {
      if (!password) return res.status(400).json({ error: 'password required for new user' });
      const existing = db.users.findByUsername(username);
      if (existing) return res.status(400).json({ error: 'username already exists' });
      const uid = db.users.create(username, await bcrypt.hash(password, 12), role);
      db.users.setServers(uid, resolvedSids);
    }

    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.delete('/users/:username', (req, res) => {
  try {
    const user = db.users.findByUsername(req.params.username);
    if (user) {
      db.users.delete(user.id);
      if (req.session.userId === user.id) req.session.destroy(() => {});
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.get('/credentials', (_req, res) => {
  try {
    res.json(db.credentials.findAll());
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.post('/credentials', (req, res) => {
  try {
    const d = req.body || {};
    const id = db.credentials.upsert({
      id: d.id || null,
      serverId: Number(d.serverId || d.sid || 0),
      type: String(d.type || 'other').trim(),
      label: String(d.label || '').trim(),
      host: String(d.host || '').trim(),
      port: String(d.port || '').trim(),
      username: String(d.username || '').trim(),
      password: String(d.password || '').trim(),
      notes: String(d.notes || '').trim(),
    });
    res.json({ ok: true, id });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.delete('/credentials/:id', (req, res) => {
  try {
    db.credentials.delete(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

module.exports = router;
