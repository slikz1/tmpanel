const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../lib/db');
const { requireLogin } = require('../middleware/auth');

const router = express.Router();
const loginAttempts = new Map();

function tooManyAttempts(ip) {
  const now = Date.now();
  const rec = loginAttempts.get(ip) || { count: 0, until: 0 };
  if (rec.until > now) return rec;
  if (rec.until && rec.until <= now) loginAttempts.delete(ip);
  return null;
}

function registerFail(ip) {
  const now = Date.now();
  const rec = loginAttempts.get(ip) || { count: 0, until: 0 };
  rec.count += 1;
  if (rec.count >= 5) rec.until = now + 10 * 60 * 1000;
  loginAttempts.set(ip, rec);
}

router.post('/login', async (req, res) => {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const blocked = tooManyAttempts(ip);
    if (blocked) {
      return res.status(429).json({ error: 'Too many login attempts. Wait 10 minutes and try again.' });
    }

    const { username, password } = req.body || {};
    if (!username || !password) {
      registerFail(ip);
      return res.status(401).json({ error: 'invalid credentials' });
    }

    const user = db.users.findByUsername(String(username).trim());
    if (!user) {
      registerFail(ip);
      return res.status(401).json({ error: 'invalid credentials' });
    }

    const ok = await bcrypt.compare(String(password), user.password_hash);
    if (!ok) {
      registerFail(ip);
      return res.status(401).json({ error: 'invalid credentials' });
    }

    loginAttempts.delete(ip);
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;

    req.session.save(function (err) {
      if (err) return res.status(500).json({ error: 'session save failed' });
      return res.json({ ok: true, user: { id: user.id, username: user.username, role: user.role } });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err.message || err) });
  }
});

router.post('/logout', (req, res) => {
  req.session.destroy(function () {
    res.clearCookie('tmsid');
    res.json({ ok: true });
  });
});

router.get('/me', requireLogin, (req, res) => {
  try {
    const user = db.users.findById(req.session.userId);
    if (!user) return res.status(401).json({ error: 'unauthorized' });

    const allServers = db.servers.findAll();
    const serverList = user.role === 'admin'
      ? allServers
      : allServers.filter(function (s) {
          return db.users.getServers(user.id).includes(s.id);
        });

    res.json({
      user: {
        id: user.id,
        username: user.username,
        role: user.role
      },
      servers: serverList.map(function (s) {
        return {
          id: s.id,
          label: s.label,
          game: s.game,
          host: s.host,
          port: s.port,
          controllerType: s.controllerType
        };
      })
    });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

module.exports = router;
