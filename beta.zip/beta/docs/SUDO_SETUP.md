# Sudo setup

Open the sudoers file safely:

```bash
visudo -f /etc/sudoers.d/tm-panel
```

Paste the rules from `examples/sudoers.txt`.

## Why this matters

The panel usually runs as `www-data`.
It needs permission to run your wrapper files, but it should not get full root access.

That is why this project uses exact shell script paths instead of broad sudo rules.
