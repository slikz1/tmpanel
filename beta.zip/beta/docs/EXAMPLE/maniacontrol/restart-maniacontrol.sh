#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server/maniacontrol}"

"$BASE/stop-maniacontrol.sh" || true
sleep 2
"$BASE/start-maniacontrol.sh"
