TRACKMANIA WRAPPER SCRIPTS

Included:
- dedicated/start-server.sh
- dedicated/stop-server.sh
- dedicated/restart-server.sh
- dedicated/status-server.sh
- xaseco/start-xaseco.sh
- xaseco/stop-xaseco.sh
- xaseco/restart-xaseco.sh
- xaseco/status-xaseco.sh
- pyplanet/start-pyplanet.sh
- pyplanet/stop-pyplanet.sh
- pyplanet/restart-pyplanet.sh
- pyplanet/status-pyplanet.sh
- maniacontrol/start-maniacontrol.sh
- maniacontrol/stop-maniacontrol.sh
- maniacontrol/restart-maniacontrol.sh
- maniacontrol/status-maniacontrol.sh

Default paths use /home/tm01/server.
You can either edit the files directly or override variables like BASE, BIN, ARGS, START_CMD.

Example:
BASE=/home/myserver/server ./start-server.sh

After extracting on Linux:
chmod +x dedicated/*.sh xaseco/*.sh pyplanet/*.sh maniacontrol/*.sh
