#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server/pyplanet}"

"$BASE/stop-pyplanet.sh" || true
sleep 2
"$BASE/start-pyplanet.sh"
