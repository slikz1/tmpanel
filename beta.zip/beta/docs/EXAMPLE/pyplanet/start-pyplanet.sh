#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server/pyplanet}"
PIDFILE="${PIDFILE:-$BASE/pyplanet.pid}"
LOGFILE="${LOGFILE:-$BASE/pyplanet.log}"
START_CMD="${START_CMD:-python3 -m pyplanet}"

cd "$BASE"

if [ -f "$PIDFILE" ]; then
  OLD_PID="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "${OLD_PID:-}" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "PyPlanet already running (PID $OLD_PID)"
    exit 0
  else
    rm -f "$PIDFILE"
  fi
fi

nohup bash -lc "$START_CMD" >> "$LOGFILE" 2>&1 &
PID=$!
echo "$PID" > "$PIDFILE"

sleep 2

if kill -0 "$PID" 2>/dev/null; then
  echo "PyPlanet started (PID $PID)"
else
  echo "ERROR: PyPlanet failed to start"
  rm -f "$PIDFILE"
  exit 1
fi
