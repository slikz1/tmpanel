#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server}"
BIN="${BIN:-$BASE/TrackmaniaServer}"
PIDFILE="${PIDFILE:-$BASE/tmserver.pid}"
LOGFILE="${LOGFILE:-$BASE/server.log}"
ARGS="${ARGS:-/game_settings=MatchSettings/server.xml /noautoquit}"

cd "$BASE"

if [ ! -x "$BIN" ]; then
  echo "ERROR: Dedicated binary not found or not executable: $BIN"
  exit 1
fi

if [ -f "$PIDFILE" ]; then
  OLD_PID="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "${OLD_PID:-}" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "Dedicated server already running (PID $OLD_PID)"
    exit 0
  else
    rm -f "$PIDFILE"
  fi
fi

nohup "$BIN" $ARGS >> "$LOGFILE" 2>&1 &
PID=$!
echo "$PID" > "$PIDFILE"

sleep 2

if kill -0 "$PID" 2>/dev/null; then
  echo "Dedicated server started (PID $PID)"
else
  echo "ERROR: Dedicated server failed to start"
  rm -f "$PIDFILE"
  exit 1
fi
