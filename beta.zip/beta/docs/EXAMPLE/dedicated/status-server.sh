#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server}"
PIDFILE="${PIDFILE:-$BASE/tmserver.pid}"

if [ -f "$PIDFILE" ]; then
  PID="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "${PID:-}" ] && kill -0 "$PID" 2>/dev/null; then
    echo "RUNNING (PID $PID)"
    exit 0
  fi
fi

PIDS="$(pgrep -f "$BASE/TrackmaniaServer" || true)"
if [ -n "$PIDS" ]; then
  echo "RUNNING ($PIDS)"
  exit 0
fi

echo "STOPPED"
exit 1
