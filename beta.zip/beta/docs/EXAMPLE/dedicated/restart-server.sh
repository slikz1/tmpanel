#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server}"

"$BASE/stop-server.sh" || true
sleep 2
"$BASE/start-server.sh"
