#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server/xaseco}"

"$BASE/stop-xaseco.sh" || true
sleep 2
"$BASE/start-xaseco.sh"
