#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server/xaseco}"
PIDFILE="${PIDFILE:-$BASE/xaseco.pid}"

if [ -f "$PIDFILE" ]; then
  PID="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "${PID:-}" ] && kill -0 "$PID" 2>/dev/null; then
    kill "$PID" || true

    for _ in 1 2 3 4 5 6 7 8 9 10; do
      if kill -0 "$PID" 2>/dev/null; then
        sleep 1
      else
        break
      fi
    done

    if kill -0 "$PID" 2>/dev/null; then
      kill -9 "$PID" || true
    fi

    rm -f "$PIDFILE"
    echo "XAseco stopped"
    exit 0
  fi
fi

PIDS="$(pgrep -f "$BASE/aseco.php" || true)"
if [ -n "$PIDS" ]; then
  echo "$PIDS" | xargs -r kill || true
  sleep 2
  echo "$PIDS" | xargs -r kill -9 || true
  rm -f "$PIDFILE"
  echo "XAseco force stopped"
  exit 0
fi

echo "XAseco is not running"
