#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-/home/tm01/server/xaseco}"
PIDFILE="${PIDFILE:-$BASE/xaseco.pid}"
LOGFILE="${LOGFILE:-$BASE/xaseco.log}"
PHP_BIN="${PHP_BIN:-/usr/bin/php}"
ASECO_FILE="${ASECO_FILE:-$BASE/aseco.php}"

cd "$BASE"

if [ ! -f "$ASECO_FILE" ]; then
  echo "ERROR: aseco.php not found: $ASECO_FILE"
  exit 1
fi

if [ -f "$PIDFILE" ]; then
  OLD_PID="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "${OLD_PID:-}" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "XAseco already running (PID $OLD_PID)"
    exit 0
  else
    rm -f "$PIDFILE"
  fi
fi

nohup "$PHP_BIN" "$ASECO_FILE" >> "$LOGFILE" 2>&1 &
PID=$!
echo "$PID" > "$PIDFILE"

sleep 2

if kill -0 "$PID" 2>/dev/null; then
  echo "XAseco started (PID $PID)"
else
  echo "ERROR: XAseco failed to start"
  rm -f "$PIDFILE"
  exit 1
fi
