# Controller setup

Choose the controller you really use.

## XAseco

Commands:

- `sudo /home/tm01/start-xaseco.sh`
- `sudo /home/tm01/stop-xaseco.sh`
- `sudo /home/tm01/restart-xaseco.sh`

## PyPlanet

Commands:

- `sudo /home/tm01/start-pyplanet.sh`
- `sudo /home/tm01/stop-pyplanet.sh`
- `sudo /home/tm01/restart-pyplanet.sh`

## ManiaControl

Commands:

- `sudo /home/tm01/start-maniacontrol.sh`
- `sudo /home/tm01/stop-maniacontrol.sh`
- `sudo /home/tm01/restart-maniacontrol.sh`

## Important

Only allow the exact wrapper files in sudoers. Do not allow full shell access.
