# First server setup

This guide is written for beginners.

## 1. Put your files in place

Example folders:

- `/home/tm01/tmserver`
- `/home/tm01/xaseco`
- `/home/tm01/pyplanet`
- `/home/tm01/maniacontrol`

## 2. Copy wrapper files

Copy the files from `examples/` to your real server home.

Example:

```bash
cp examples/start-server.sh /home/tm01/start-server.sh
cp examples/stop-server.sh /home/tm01/stop-server.sh
cp examples/restart-server.sh /home/tm01/restart-server.sh
chmod +x /home/tm01/*.sh
```

Then edit the paths inside the files if your folders are different.

## 3. Add sudo rules

Create `/etc/sudoers.d/tm-panel` and paste the content from `examples/sudoers.txt`.

Use:

```bash
visudo -f /etc/sudoers.d/tm-panel
```

## 4. What to enter in the installer

- **TrackMania root**: your dedicated server folder, for example `/home/tm01/tmserver`
- **Files root**: usually the same as TrackMania root or `/home/tm01`
- **Maps path**: usually `/home/tm01/tmserver/GameData/Tracks`
- **MatchSettings path**: usually `/home/tm01/tmserver/GameData/Tracks/MatchSettings`
- **Start command**: `sudo /home/tm01/start-server.sh`
- **Stop command**: `sudo /home/tm01/stop-server.sh`
- **Restart command**: `sudo /home/tm01/restart-server.sh`

## 5. Test commands manually first

Before using the panel, run every command once in SSH.

```bash
sudo /home/tm01/start-server.sh
sudo /home/tm01/stop-server.sh
sudo /home/tm01/restart-server.sh
```

If these commands work in SSH, the panel can use the same commands.
