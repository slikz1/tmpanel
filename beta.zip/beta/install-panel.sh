#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

say(){ printf '\n==> %s\n' "$1"; }
warn(){ printf '\n[WARN] %s\n' "$1"; }
ask(){ local p="$1" d="${2-}" r; if [ -n "$d" ]; then read -r -p "$p [$d]: " r || true; printf '%s' "${r:-$d}"; else read -r -p "$p: " r || true; printf '%s' "$r"; fi; }
ask_secret(){ local p="$1" a b; while true; do read -r -s -p "$p: " a; echo; read -r -s -p "Repeat ${p,,}: " b; echo; [ "$a" = "$b" ] || { warn "Passwords do not match."; continue; }; [ ${#a} -ge 8 ] || { warn "Password must be at least 8 chars."; continue; }; printf '%s' "$a"; return; done; }
command_exists(){ command -v "$1" >/dev/null 2>&1; }
ensure_pkg(){ local pkgs=("$@"); if command_exists apt-get; then DEBIAN_FRONTEND=noninteractive apt-get update -y; DEBIAN_FRONTEND=noninteractive apt-get install -y "${pkgs[@]}"; else warn "Install these packages manually: ${pkgs[*]}"; fi; }
find_free_port(){ python3 - <<'PY'
import socket
cands=[3000,3001,3002,8088,8080,5000]
for p in cands:
    s=socket.socket()
    try:
        s.bind(('0.0.0.0',p))
        s.close()
        print(p)
        break
    except OSError:
        pass
else:
    s=socket.socket(); s.bind(('0.0.0.0',0)); print(s.getsockname()[1]); s.close()
PY
}
get_ip(){ hostname -I 2>/dev/null | awk '{print $1}'; }
is_ip(){ printf '%s' "$1" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'; }

[ "${EUID}" -eq 0 ] || { echo "Run this installer as root."; exit 1; }

say "Installing required packages"
ensure_pkg curl ca-certificates unzip screen sqlite3 nginx certbot python3-certbot-nginx
if ! command_exists node; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  ensure_pkg nodejs
fi

say "Checking Node.js"
NODE_MAJOR="$(node -v | sed 's/^v//' | cut -d. -f1)"
[ "${NODE_MAJOR:-0}" -ge 18 ] || { echo "Node.js 18+ required"; exit 1; }

say "Installing npm packages"
npm install
mkdir -p data data/backups data/uploads data/sessions data/logs deploy tools
chmod +x examples/*.sh 2>/dev/null || true
chmod +x tools/*.sh 2>/dev/null || true

HOSTNAME_DEF="$(hostname -f 2>/dev/null || hostname)"
IP_DEF="$(get_ip)"
PORT_DEF="$(find_free_port)"

say "Panel setup"
ADMIN_USER="$(ask 'Admin username' 'admin')"
ADMIN_EMAIL="$(ask 'Admin email' 'admin@example.com')"
ADMIN_PASS="$(ask_secret 'Admin password (min 8 chars)')"

say "Server setup"
SERVER_LABEL="$(ask 'First server label' 'Main Server')"
TM_ROOT="$(ask 'TrackMania root path' '/home/tm01/tmserver')"
[ -d "$TM_ROOT" ] || warn "Path does not exist yet. It will be created."
FILES_ROOT="$(ask 'Files root path' "$TM_ROOT")"
SERVER_USER="$(ask 'Linux user for the dedicated server' 'root')"
SERVER_HOST="$(ask 'Game server host/IP' '127.0.0.1')"
SERVER_PORT="$(ask 'Game server port' '5000')"
RPC_USER="$(ask 'RPC username' 'SuperAdmin')"
read -r -s -p 'RPC password: ' RPC_PASS; echo
CONTROLLER_TYPE="$(ask 'Controller type (none/xaseco/pyplanet/maniacontrol)' 'none')"
BINARY_NAME="$(ask 'Dedicated binary name' 'TrackmaniaServer')"
START_ARGS="$(ask 'Dedicated start arguments' '/game_settings=MatchSettings/server.xml /noautoquit')"
SERVICE_NAME="$(ask 'Panel service name' 'tm-panel')"

say "Web / reverse proxy setup"
PANEL_PORT="$(ask 'Panel listen port' "$PORT_DEF")"
PUBLIC_HOST="$(ask 'Domain or hostname for the panel (domain preferred, IP allowed)' "$HOSTNAME_DEF")"
SSL_ENABLE="$(ask "Enable Let's Encrypt SSL? (y/n)" 'y')"
if is_ip "$PUBLIC_HOST"; then SSL_ENABLE='n'; fi

export PANEL_ADMIN_USER="$ADMIN_USER"
export PANEL_ADMIN_EMAIL="$ADMIN_EMAIL"
export PANEL_ADMIN_PASS="$ADMIN_PASS"
export PANEL_SERVER_LABEL="$SERVER_LABEL"
export PANEL_TM_ROOT="$TM_ROOT"
export PANEL_FILES_ROOT="$FILES_ROOT"
export PANEL_SERVER_USER="$SERVER_USER"
export PANEL_SERVER_HOST="$SERVER_HOST"
export PANEL_SERVER_PORT="$SERVER_PORT"
export PANEL_RPC_USER="$RPC_USER"
export PANEL_RPC_PASS="$RPC_PASS"
export PANEL_CONTROLLER_TYPE="$CONTROLLER_TYPE"
export PANEL_BINARY_NAME="$BINARY_NAME"
export PANEL_START_ARGS="$START_ARGS"
export PANEL_SERVICE_NAME="$SERVICE_NAME"
export PANEL_PORT="$PANEL_PORT"
export PANEL_HOST="$HOSTNAME_DEF"
export PANEL_PUBLIC_HOST="$PUBLIC_HOST"
export PANEL_URL="$( is_ip "$PUBLIC_HOST" && echo "http://$PUBLIC_HOST" || echo "https://$PUBLIC_HOST" )"

say "Writing panel configuration and first admin/server into the database"
SUMMARY_JSON="$(node tools/sh-installer.js)"
echo "$SUMMARY_JSON" > deploy/install-summary.json

say "Installing systemd service"
cp "deploy/${SERVICE_NAME}.service" "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

say "Configuring nginx"
NGINX_FILE="/etc/nginx/sites-available/${SERVICE_NAME}.conf"
cat > "$NGINX_FILE" <<NGINX
server {
    listen 80;
    server_name ${PUBLIC_HOST};

    client_max_body_size 2G;

    location / {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
NGINX
ln -sf "$NGINX_FILE" "/etc/nginx/sites-enabled/${SERVICE_NAME}.conf"
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

FINAL_URL="http://${PUBLIC_HOST}"
if [ "${SSL_ENABLE}" = "y" ] && ! is_ip "$PUBLIC_HOST"; then
  say "Requesting Let's Encrypt certificate"
  certbot --nginx -d "$PUBLIC_HOST" --non-interactive --agree-tos -m "$ADMIN_EMAIL" --redirect || warn "Certbot failed. Site stays on HTTP until DNS points correctly."
  if [ -f "/etc/letsencrypt/live/${PUBLIC_HOST}/fullchain.pem" ]; then
    nginx -t && systemctl reload nginx
    FINAL_URL="https://${PUBLIC_HOST}"
  fi
fi

printf '\n========================================\n'
printf 'Panel ready: %s\n' "$FINAL_URL"
printf 'Login user: %s\n' "$ADMIN_USER"
printf 'Service: systemctl status %s\n' "$SERVICE_NAME"
printf 'Nginx: %s\n' "$NGINX_FILE"
printf 'Summary: %s/deploy/install-summary.json\n' "$APP_DIR"
printf '========================================\n\n'
