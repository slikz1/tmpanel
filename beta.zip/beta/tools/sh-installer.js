#!/usr/bin/env node
const fs = require('fs');
const os = require('os');
const path = require('path');
const bcrypt = require('bcryptjs');

function env(name, fallback = '') {
  const v = process.env[name];
  return v == null || v === '' ? fallback : String(v);
}
function yn(v) {
  return /^(1|true|yes|y|on)$/i.test(String(v || '').trim());
}
function safeName(v, fallback = 'tm-panel') {
  return String(v || fallback).trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || fallback;
}
function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}
function writeExe(file, content) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, content, 'utf8');
  fs.chmodSync(file, 0o755);
}
function exists(p) { try { return fs.existsSync(p); } catch { return false; } }
function isIp(host) { return /^(\d{1,3}\.){3}\d{1,3}$/.test(String(host || '').trim()); }
function detectMapsPath(tmRoot) {
  const candidates = [
    path.join(tmRoot, 'GameData', 'Tracks'),
    path.join(tmRoot, 'Tracks'),
  ];
  return candidates.find(exists) || candidates[0];
}
function detectMatchPath(tmRoot) {
  const candidates = [
    path.join(tmRoot, 'GameData', 'Tracks', 'MatchSettings'),
    path.join(tmRoot, 'MatchSettings'),
  ];
  return candidates.find(exists) || candidates[0];
}
function detectControllerDir(filesRoot, controllerType) {
  const type = String(controllerType || 'none').toLowerCase();
  if (type === 'pyplanet') return path.join(filesRoot, 'pyplanet');
  if (type === 'xaseco') return path.join(filesRoot, 'xaseco');
  if (type === 'maniacontrol') return path.join(filesRoot, 'maniacontrol');
  return filesRoot;
}
function buildStartArgs(v) {
  const s = String(v || '').trim();
  return s || '/game_settings=MatchSettings/server.xml /noautoquit';
}

(async function main() {
  const root = path.resolve(__dirname, '..');
  process.chdir(root);

  ensureDir(path.join(root, 'data'));
  ensureDir(path.join(root, 'deploy'));
  ensureDir(path.join(root, 'data', 'backups'));
  ensureDir(path.join(root, 'data', 'uploads'));
  ensureDir(path.join(root, 'data', 'sessions'));
  ensureDir(path.join(root, 'data', 'logs'));

  if (!process.env.DATABASE_URL) {
    process.env.DATABASE_URL = 'file:./data/tm_panel.db';
  }

  const db = require('../src/lib/db');

  const adminUser = env('PANEL_ADMIN_USER', 'admin').trim();
  const adminMail = env('PANEL_ADMIN_EMAIL', '').trim();
  const adminPass = env('PANEL_ADMIN_PASS', '').trim();
  if (!adminPass || adminPass.length < 8) throw new Error('Admin password missing or too short.');

  const label = env('PANEL_SERVER_LABEL', 'Main Server').trim();
  const tmRoot = path.resolve(env('PANEL_TM_ROOT', '/home/tm01/tmserver').trim());
  const filesRoot = path.resolve(env('PANEL_FILES_ROOT', tmRoot).trim());
  const serverUser = env('PANEL_SERVER_USER', 'tm').trim();
  const serverHost = env('PANEL_SERVER_HOST', '127.0.0.1').trim();
  const serverPort = Number(env('PANEL_SERVER_PORT', '5000')) || 5000;
  const rpcUser = env('PANEL_RPC_USER', 'SuperAdmin').trim();
  const rpcPass = env('PANEL_RPC_PASS', '').trim();
  const controllerType = env('PANEL_CONTROLLER_TYPE', 'none').trim().toLowerCase();
  const binaryName = env('PANEL_BINARY_NAME', 'TrackmaniaServer').trim();
  const startArgs = buildStartArgs(env('PANEL_START_ARGS', ''));
  const panelPort = Number(env('PANEL_PORT', '3000')) || 3000;
  const panelHost = env('PANEL_HOST', os.hostname()).trim();
  const publicHost = env('PANEL_PUBLIC_HOST', panelHost).trim();
  const panelUrl = env('PANEL_URL', `${isIp(publicHost) ? 'http' : 'https'}://${publicHost}`).trim();
  const serviceName = safeName(env('PANEL_SERVICE_NAME', 'tm-panel'));

  ensureDir(filesRoot);
  ensureDir(tmRoot);

  const mapsPath = detectMapsPath(tmRoot);
  const matchPath = detectMatchPath(tmRoot);
  ensureDir(mapsPath);
  ensureDir(matchPath);

  const ctrlDir = path.resolve(env('PANEL_CONTROLLER_DIR', detectControllerDir(filesRoot, controllerType)).trim());
  ensureDir(ctrlDir);

  const dedStart = path.join(filesRoot, 'start-server.sh');
  const dedStop = path.join(filesRoot, 'stop-server.sh');
  const dedRestart = path.join(filesRoot, 'restart-server.sh');
  const dedStatus = path.join(filesRoot, 'status-server.sh');
  const workDir = exists(tmRoot) ? tmRoot : filesRoot;
  const binPath = path.join(workDir, binaryName);
  const pidFile = path.join(filesRoot, 'tmserver.pid');

  writeExe(dedStart, `#!/usr/bin/env bash
set -e
cd "${workDir}" || exit 1
if [ -f "${pidFile}" ] && kill -0 "$(cat "${pidFile}")" 2>/dev/null; then
  echo "Server already running"
  exit 0
fi
nohup ${serverUser && serverUser !== 'root' ? `sudo -u ${serverUser} ` : ''}"${binPath}" ${startArgs} > "${path.join(filesRoot, 'server.out.log')}" 2>&1 &
echo $! > "${pidFile}"
echo "Started"
`);

  writeExe(dedStop, `#!/usr/bin/env bash
set +e
if [ -f "${pidFile}" ]; then
  PID="$(cat "${pidFile}")"
  kill "$PID" 2>/dev/null || true
  sleep 2
  kill -9 "$PID" 2>/dev/null || true
  rm -f "${pidFile}"
fi
pkill -f "${binaryName}" 2>/dev/null || true
echo "Stopped"
`);

  writeExe(dedRestart, `#!/usr/bin/env bash
set -e
"${dedStop}"
sleep 2
"${dedStart}"
`);

  writeExe(dedStatus, `#!/usr/bin/env bash
if [ -f "${pidFile}" ] && kill -0 "$(cat "${pidFile}")" 2>/dev/null; then
  echo ONLINE
  exit 0
fi
pgrep -f "${binaryName}" >/dev/null 2>&1 && echo ONLINE && exit 0
echo OFFLINE
exit 1
`);

  let ctl = null;
  if (controllerType === 'pyplanet' || controllerType === 'xaseco' || controllerType === 'maniacontrol') {
    const names = {
      pyplanet: ['start-pyplanet.sh','stop-pyplanet.sh','restart-pyplanet.sh','status-pyplanet.sh'],
      xaseco: ['start-xaseco.sh','stop-xaseco.sh','restart-xaseco.sh','status-xaseco.sh'],
      maniacontrol: ['start-maniacontrol.sh','stop-maniacontrol.sh','restart-maniacontrol.sh','status-maniacontrol.sh']
    }[controllerType];

    ctl = {
      start: path.join(ctrlDir, names[0]),
      stop: path.join(ctrlDir, names[1]),
      restart: path.join(ctrlDir, names[2]),
      status: path.join(ctrlDir, names[3]),
    };

    if (controllerType === 'pyplanet') {
      writeExe(ctl.start, `#!/usr/bin/env bash
cd "${ctrlDir}" || exit 1
if [ -x ./pyplanet.sh ]; then exec ./pyplanet.sh start; fi
nohup python3 -m pyplanet > pyplanet.log 2>&1 &
`);
      writeExe(ctl.stop, `#!/usr/bin/env bash
cd "${ctrlDir}" || exit 1
if [ -x ./pyplanet.sh ]; then exec ./pyplanet.sh stop; fi
pkill -f pyplanet 2>/dev/null || true
`);
      writeExe(ctl.restart, `#!/usr/bin/env bash
cd "${ctrlDir}" || exit 1
if [ -x ./pyplanet.sh ]; then exec ./pyplanet.sh restart; fi
pkill -f pyplanet 2>/dev/null || true
sleep 2
nohup python3 -m pyplanet > pyplanet.log 2>&1 &
`);
      writeExe(ctl.status, `#!/usr/bin/env bash
pgrep -f pyplanet >/dev/null 2>&1 && echo ONLINE || echo OFFLINE
`);
    }

    if (controllerType === 'xaseco') {
      writeExe(ctl.start, `#!/usr/bin/env bash
cd "${ctrlDir}" || exit 1
nohup php aseco.php > aseco.log 2>&1 &
`);
      writeExe(ctl.stop, `#!/usr/bin/env bash
pkill -f aseco.php 2>/dev/null || true
`);
      writeExe(ctl.restart, `#!/usr/bin/env bash
pkill -f aseco.php 2>/dev/null || true
sleep 2
cd "${ctrlDir}" || exit 1
nohup php aseco.php > aseco.log 2>&1 &
`);
      writeExe(ctl.status, `#!/usr/bin/env bash
pgrep -f aseco.php >/dev/null 2>&1 && echo ONLINE || echo OFFLINE
`);
    }

    if (controllerType === 'maniacontrol') {
      writeExe(ctl.start, `#!/usr/bin/env bash
cd "${ctrlDir}" || exit 1
nohup php ManiaControl.php > maniacontrol.log 2>&1 &
`);
      writeExe(ctl.stop, `#!/usr/bin/env bash
pkill -f ManiaControl.php 2>/dev/null || true
`);
      writeExe(ctl.restart, `#!/usr/bin/env bash
pkill -f ManiaControl.php 2>/dev/null || true
sleep 2
cd "${ctrlDir}" || exit 1
nohup php ManiaControl.php > maniacontrol.log 2>&1 &
`);
      writeExe(ctl.status, `#!/usr/bin/env bash
pgrep -f ManiaControl.php >/dev/null 2>&1 && echo ONLINE || echo OFFLINE
`);
    }
  }

  const envFile = path.join(root, '.env');
  fs.writeFileSync(envFile, [
    `PORT=${panelPort}`,
    `APP_NAME=TRACKMANIA WEB PANEL`,
    `PANEL_URL=${panelUrl}`,
    `SESSION_SECRET=${env('PANEL_SESSION_SECRET', require('crypto').randomBytes(24).toString('hex'))}`,
    `DATABASE_URL=file:./data/tm_panel.db`,
    `NODE_ENV=production`
  ].join('\n') + '\n', 'utf8');

  await db.init();

  const hash = await bcrypt.hash(adminPass, 12);
  let user = db.users.findByUsername(adminUser);
  if (!user) {
    const id = db.users.create(adminUser, hash, 'admin');
    user = db.users.findById(id);
  } else {
    db.users.update(user.id, { password_hash: hash, role: 'admin' });
    user = db.users.findById(user.id);
  }

  const serverId = db.servers.create({
    label,
    game: 'TrackMania',
    host: serverHost,
    port: serverPort,
    rpcUser,
    rpcPass,
    mapsPath,
    matchPath,
    filesRoot,
    dedicatedCmds: {
      start: dedStart,
      stop: dedStop,
      restart: dedRestart,
      status: dedStatus,
      binaryName,
      tmRoot,
      startArgs
    },
    pyplanetCmds: {},
    controllerType,
    controllerCmds: ctl ? {
      start: ctl.start,
      stop: ctl.stop,
      restart: ctl.restart,
      status: ctl.status
    } : {},
    backupConfig: {},
    controllerEnabled: controllerType !== 'none'
  });

  db.users.setServers(user.id, [serverId]);

  const serviceFile = path.join(root, 'deploy', `${serviceName}.service`);
  fs.writeFileSync(serviceFile, `[Unit]
Description=TrackMania Web Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=${root}
ExecStart=/usr/bin/node ${path.join(root, 'src', 'index.js')}
Restart=always
RestartSec=3
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
`, 'utf8');

  const lockFile = path.join(root, 'data', 'install.lock');
  fs.writeFileSync(lockFile, JSON.stringify({
    installed: true,
    at: new Date().toISOString(),
    admin: adminUser,
    email: adminMail,
    serverId
  }, null, 2));

  const dbPath = path.join(root, 'data', 'tm_panel.db');
  if (!fs.existsSync(dbPath)) {
    throw new Error(`DB was not created: ${dbPath}`);
  }

  process.stdout.write(JSON.stringify({
    ok: true,
    dbPath,
    serviceName,
    serverId,
    panelUrl
  }, null, 2));
})().catch(err => {
  console.error(err);
  process.exit(1);
});
