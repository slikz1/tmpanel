#!/usr/bin/env bash
set -euo pipefail

say() { printf '\n==> %s\n' "$1"; }
ask() {
  local prompt="$1" default="${2:-}" value
  if [ -n "$default" ]; then
    read -r -p "$prompt [$default]: " value
    echo "${value:-$default}"
  else
    read -r -p "$prompt: " value
    echo "$value"
  fi
}

say "TrackMania server setup wizard"

SERVER_LABEL="$(ask 'Server label' 'Main Server')"
SERVER_DIR="$(ask 'Server folder' '/home/tm01/server')"
RUN_USER="$(ask 'Linux user that should run the server' "$USER")"
BINARY_NAME="$(ask 'Dedicated binary name' 'TrackmaniaServer')"
START_ARGS="$(ask 'Start arguments' '/game_settings=MatchSettings/server.xml')"
SERVICE_NAME="$(ask 'systemd service name' 'tm-main')"
CONTROLLER_TYPE="$(ask 'Controller (none/xaseco/pyplanet/maniacontrol)' 'none')"

mkdir -p "$SERVER_DIR"
mkdir -p "$SERVER_DIR/GameData/Tracks/MatchSettings"

cat > "$SERVER_DIR/start-server.sh" <<SCRIPT
#!/usr/bin/env bash
set -e
cd "$SERVER_DIR" || exit 1
if pgrep -af "$BINARY_NAME" >/dev/null; then
  echo "Server is already running"
  exit 0
fi
sudo -u "$RUN_USER" screen -dmS "$SERVICE_NAME" "$SERVER_DIR/$BINARY_NAME" $START_ARGS
SCRIPT

cat > "$SERVER_DIR/stop-server.sh" <<SCRIPT
#!/usr/bin/env bash
set -e
pkill -f "$BINARY_NAME" || true
SCRIPT

cat > "$SERVER_DIR/restart-server.sh" <<SCRIPT
#!/usr/bin/env bash
set -e
"$SERVER_DIR/stop-server.sh"
sleep 2
"$SERVER_DIR/start-server.sh"
SCRIPT

cat > "$SERVER_DIR/status-server.sh" <<SCRIPT
#!/usr/bin/env bash
if pgrep -af "$BINARY_NAME" >/dev/null; then
  echo "ONLINE"
  exit 0
fi
echo "OFFLINE"
exit 1
SCRIPT

chmod +x "$SERVER_DIR"/start-server.sh "$SERVER_DIR"/stop-server.sh "$SERVER_DIR"/restart-server.sh "$SERVER_DIR"/status-server.sh

CTRL_DIR=""
if [[ "$CONTROLLER_TYPE" == "xaseco" || "$CONTROLLER_TYPE" == "pyplanet" || "$CONTROLLER_TYPE" == "maniacontrol" ]]; then
  CTRL_DIR="$(ask 'Controller folder' "$SERVER_DIR/$CONTROLLER_TYPE")"
  CTRL_PROCESS="$(ask 'Controller process name' "$CONTROLLER_TYPE")"
  mkdir -p "$CTRL_DIR"

  cat > "$CTRL_DIR/start-$CONTROLLER_TYPE.sh" <<SCRIPT
#!/usr/bin/env bash
set -e
cd "$CTRL_DIR" || exit 1
echo "Replace this file with the real $CONTROLLER_TYPE start command"
SCRIPT

  cat > "$CTRL_DIR/stop-$CONTROLLER_TYPE.sh" <<SCRIPT
#!/usr/bin/env bash
pkill -f "$CTRL_PROCESS" || true
SCRIPT

  cat > "$CTRL_DIR/restart-$CONTROLLER_TYPE.sh" <<SCRIPT
#!/usr/bin/env bash
set -e
"$CTRL_DIR/stop-$CONTROLLER_TYPE.sh"
sleep 2
"$CTRL_DIR/start-$CONTROLLER_TYPE.sh"
SCRIPT

  cat > "$CTRL_DIR/status-$CONTROLLER_TYPE.sh" <<SCRIPT
#!/usr/bin/env bash
if pgrep -af "$CTRL_PROCESS" >/dev/null; then
  echo "ONLINE"
  exit 0
fi
echo "OFFLINE"
exit 1
SCRIPT

  chmod +x "$CTRL_DIR"/start-$CONTROLLER_TYPE.sh "$CTRL_DIR"/stop-$CONTROLLER_TYPE.sh "$CTRL_DIR"/restart-$CONTROLLER_TYPE.sh "$CTRL_DIR"/status-$CONTROLLER_TYPE.sh
fi

cat > "$SERVER_DIR/$SERVICE_NAME.service.example" <<SERVICE
[Unit]
Description=TrackMania Server - $SERVER_LABEL
After=network.target

[Service]
Type=forking
User=$RUN_USER
WorkingDirectory=$SERVER_DIR
ExecStart=$SERVER_DIR/start-server.sh
ExecStop=$SERVER_DIR/stop-server.sh
ExecReload=$SERVER_DIR/restart-server.sh
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
SERVICE

cat <<INFO

DONE.

Created files:
  $SERVER_DIR/start-server.sh
  $SERVER_DIR/stop-server.sh
  $SERVER_DIR/restart-server.sh
  $SERVER_DIR/status-server.sh
  $SERVER_DIR/$SERVICE_NAME.service.example

Panel values:

Server name:
  $SERVER_LABEL

TrackMania root:
  $SERVER_DIR

Files root:
  $SERVER_DIR

Maps path:
  $SERVER_DIR/GameData/Tracks

MatchSettings path:
  $SERVER_DIR/GameData/Tracks/MatchSettings

Start command:
  sudo $SERVER_DIR/start-server.sh

Stop command:
  sudo $SERVER_DIR/stop-server.sh

Restart command:
  sudo $SERVER_DIR/restart-server.sh

Status command:
  sudo $SERVER_DIR/status-server.sh

IMPORTANT:
- Put the dedicated binary into $SERVER_DIR if it is not there yet.
- Update sudoers so the panel may run these scripts.
- Copy the service example into /etc/systemd/system/ if you want per-server systemd.
INFO
